// ignore_for_file: unused_element

import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:fs_dart/halaman/awal/halaman_awal.dart';
import 'package:page_transition/page_transition.dart';
import 'package:fs_dart/halaman/edit/layout.dart';
import 'package:localstorage/localstorage.dart';
import 'package:fs_dart/src/database/db.dart';
import 'package:fs_dart/src/variables.g.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:wave/config.dart';
import 'package:wave/wave.dart';
// import 'sticker.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:ui';

class BackgroundNewWidget extends StatefulWidget {
  BackgroundNewWidget({
    super.key,
    required this.nama,
    required this.title,
    required this.nama_filter,
    required this.choose_layout,
    required this.choose_layout2,
    required this.drag_item,
    required this.drag_item2,
    required this.backgrounds,
  });
  final nama;
  final title;
  final nama_filter;
  final choose_layout;
  final choose_layout2;
  final drag_item;
  final drag_item2;
  final backgrounds;

  @override
  State<BackgroundNewWidget> createState() => _LayoutWidgetState(
        this.nama,
        this.title,
        this.nama_filter,
        this.choose_layout,
        this.choose_layout2,
        this.drag_item,
        this.drag_item2,
        this.backgrounds,
      );
}

class _LayoutWidgetState extends State<BackgroundNewWidget> {
  final nama;
  final title;
  final nama_filter;
  final choose_layout;
  final choose_layout2;

  final drag_item;
  final drag_item2;
  final backgrounds;

  // ...
  final double barHeight = 10.0;

  // colors wave
  static const _durations = [
    10000,
    75000,
  ];

  static const _heightPercentages = [
    0.90,
    0.70,
  ];
  // end statements color waves

  var db = new Mysql();

  var stores;
  var dragItems;

  var bg_warna_main = "";
  var warna1 = "";
  var warna2 = "";

  bool isLayout1 = false;
  bool isLayout2 = false;
  bool isLayout3 = false;
  bool isLayout4 = false;
  bool isLayout5 = false;
  bool isLayout6 = false;

  bool isBackground1 = false;
  bool isBackground2 = false;
  bool isBackground3 = false;
  bool isBackground4 = false;
  bool isBackground5 = false;
  bool isBackground6 = false;

  bool isFilterBeauty = false;

  String choose_background = '';

  // drag item untuk page layout b...
  List dragItemB1 = [];
  List dragItemB2 = [];

  int lengthDataItem1 = 0;
  int lengthDataItem2 = 0;
  // drag item untuk page layout b...

  String deskripsi = "";
  String nama_user = "";
  String email_user = "";
  String ig = "";

  int lengthDataImages = 0;
  int no_telp = 0;
  int harga = 0;

  List<dynamic> listUploads = [];
  List<dynamic> list = [];

  List<dynamic> url_image = [];

  List<dynamic> url_image_b1 = [];
  List<dynamic> url_image_b2 = [];

  List<dynamic> background = [];
  List<dynamic> background_image = [];

  // background image dan header variables
  String headerImg = "";
  String bgImg = "";
  // ...

  String pilih_kanvas = "";
  String pilih_background1 = "";
  String pilih_background2 = "";

  String string_logo = "";

  bool isChooseBgKanvas1 = false;
  bool isChooseBgKanvas2 = false;

  final LocalStorage storage = new LocalStorage('serial_key');

  _LayoutWidgetState(
    this.nama,
    this.title,
    this.nama_filter,
    this.choose_layout,
    this.choose_layout2,
    this.drag_item,
    this.drag_item2,
    this.backgrounds,
  );

  @override
  void initState() {
    // TODO: implement initState
    // deleteFolderEditImages();
    getBackground();
    getWarnaBg();
    getAllImages();
    getSettings();

    // ...
    getOrderSettings();

    print("drag item 1 : $drag_item");
    print("drag item 2 : $drag_item2");
    print("choose_layout pada backgrond page : $choose_layout");
    print("choose_layout2 pada backgrond page : $choose_layout2");
    super.initState();
  }

  getOrderSettings() async {
    var request =
        http.Request('GET', Uri.parse('http://127.0.0.1:8000/api/order-get'));
    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);
    if (response.statusCode == 200) {
      final result = jsonDecode(response.body) as List<dynamic>;
      background.addAll(result);
      for (var element in background) {
        setState(() {
          // headerImg = element["header_image"];
          bgImg = element["background_image"];
        });
      }
      print("object : $bgImg");
    } else {
      print(response.reasonPhrase);
    }
  }

  getSettings() async {
    db.getConnection().then(
      (value) {
        String sql = "select * from `settings`";
        value.query(sql).then((value) {
          for (var row in value) {
            setState(() {
              string_logo = row[7];
            });
          } // Finally, close the connection
        }).then((value) => print("object string logo : $string_logo"));
        return value.close();
      },
    );
  }

  // get background from api
  getBackground() async {
    var request =
        http.Request('GET', Uri.parse('http://127.0.0.1:8000/api/background'));
    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);
    if (response.statusCode == 200) {
      final result = jsonDecode(response.body) as List<dynamic>;
      background.addAll(result);
    } else {
      print(response.reasonPhrase);
    }
  }

  getWarnaBg() async {
    db.getConnection().then(
      (value) {
        String sql = "select * from `main_color`";
        value.query(sql).then((value) {
          for (var row in value) {
            setState(() {
              bg_warna_main = row[1];
              warna1 = row[2];
              warna2 = row[3];
            });
          } // Finally, close the connection
        }).then((value) {
          // ...
          print("bg main color : $bg_warna_main");
          print("bg main color : $warna1");
          print("bg main color : $warna2");
        });
        return value.close();
      },
    );
  }

  // delete functions
  Future<void> deleteFolderEditImages() async {
    var request = http.MultipartRequest(
        'POST', Uri.parse('http://127.0.0.1:8000/api/delete-folder-edit'));
    request.fields.addAll({
      'folder_name':
          'uploads/images/$nama-${DateTime.now().day}-${DateTime.now().hour}'
    });

    http.StreamedResponse response = await request.send();

    print("delete folder");
    var counter = 2;
    Timer.periodic(const Duration(seconds: 1), (timer) {
      counter--;
      if (counter == 0) {
        // get all images
      }
    });

    if (response.statusCode == 200) {
      print(await response.stream.bytesToString());
    } else {
      print(response.reasonPhrase);
    }
  }

  Future<void> getAllImages() async {
    var request = http.MultipartRequest(
      'POST',
      Uri.parse(
        '${Variables.ipv4_local}/api/show-images-edit',
      ),
    );
    request.fields.addAll(
      {
        'nama': "$nama-${DateTime.now().day}-${DateTime.now().hour}",
      },
    );

    print(
        "nama image pada background page : $nama-${DateTime.now().day}-${DateTime.now().hour}");

    http.Response response =
        await http.Response.fromStream(await request.send());

    if (response.statusCode == 201) {
      stores = jsonDecode(response.body);

      setState(() {});
      list.addAll(jsonDecode(response.body));
      setState(() {
        lengthDataImages = stores.length;
      });

      print("list images : $list");
      // ......
      // card 1
      // ......
      if (title.toString().contains("Collage B") ||
          title.toString().contains("Paket B")) {
        // layout 1
        if (choose_layout == "layout 1") {
          // if (drag_item[0].isNotEmpty) {
          if (drag_item[0].toString().contains("00") &&
              drag_item[0].toString().isNotEmpty) {
            url_image_b1.add(list[0]);
            print("url_image : $url_image");
          }
          if (drag_item[0].toString().contains("01") &&
              drag_item[0].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[1]);
            print("url_image : $url_image");
          }
          if (drag_item[0].toString().contains("02") &&
              drag_item[0].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[2]);
            print("url_image : $url_image");
          }
          if (drag_item[0].toString().contains("03") &&
              drag_item[0].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[3]);
            print("url_image : $url_image");
          }
          if (drag_item[0].toString().contains("10") &&
              drag_item[0].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[4]);
            print("url_image : $url_image");
          }
          if (drag_item[0].toString().contains("11") &&
              drag_item[0].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[5]);
            print("url_image : $url_image");
          }
          if (drag_item[0].toString().contains("12") &&
              drag_item[0].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[6]);
            print("url_image : $url_image");
          }
          if (drag_item[0].toString().contains("13") &&
              drag_item[0].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[7]);
            print("url_image : $url_image");
          }

          // ......
          // card 2
          // ......
          if (drag_item2[1].isNotEmpty) {
            if (drag_item[1].toString().contains("00") &&
                drag_item[1].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("01") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("02") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("03") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("10") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("11") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("12") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("13") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 3
          // ......
          if (drag_item[2].isNotEmpty) {
            if (drag_item[2].toString().contains("00") &&
                drag_item[2].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("01") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("02") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("03") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[2].toString().contains("10") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("11") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("12") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("13") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 4
          // ......
          if (drag_item[3].isNotEmpty) {
            if (drag_item[3].toString().contains("00") &&
                drag_item[3].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("01") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("02") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("03") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("10") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("11") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("12") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("13") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 5
          // ......
          if (drag_item[4].toString().contains("00") &&
              drag_item[4].toString().isNotEmpty) {
            url_image_b1.add(list[0]);
            print("url_image : $url_image");
          }
          if (drag_item[4].toString().contains("01") &&
              drag_item[4].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[1]);
            print("url_image : $url_image");
          }
          if (drag_item[4].toString().contains("02") &&
              drag_item[4].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[2]);
            print("url_image : $url_image");
          }
          if (drag_item[4].toString().contains("03") &&
              drag_item[4].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[3]);
            print("url_image : $url_image");
          }
          if (drag_item[4].toString().contains("10") &&
              drag_item[4].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[4]);
            print("url_image : $url_image");
          }
          if (drag_item[4].toString().contains("11") &&
              drag_item[4].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[5]);
            print("url_image : $url_image");
          }
          if (drag_item[4].toString().contains("12") &&
              drag_item[4].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[6]);
            print("url_image : $url_image");
          }
          if (drag_item[4].toString().contains("13") &&
              drag_item[4].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[7]);
            print("url_image : $url_image");
          }

          // ......
          // card 6
          // ......
          if (drag_item[5].toString().contains("00") &&
              drag_item[5].toString().isNotEmpty) {
            url_image_b1.add(list[0]);
            print("url_image : $url_image");
          }
          if (drag_item[5].toString().contains("01") &&
              drag_item[5].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[1]);
            print("url_image : $url_image");
          }
          if (drag_item[5].toString().contains("02") &&
              drag_item[5].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[2]);
            print("url_image : $url_image");
          }
          if (drag_item[5].toString().contains("03") &&
              drag_item[5].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[3]);
            print("url_image : $url_image");
          }

          if (drag_item[5].toString().contains("10") &&
              drag_item[5].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[4]);
            print("url_image : $url_image");
          }
          if (drag_item[5].toString().contains("11") &&
              drag_item[5].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[5]);
            print("url_image : $url_image");
          }
          if (drag_item[5].toString().contains("12") &&
              drag_item[5].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[6]);
            print("url_image : $url_image");
          }
          if (drag_item[5].toString().contains("13") &&
              drag_item[5].toString().isNotEmpty) {
            // ...
            url_image_b1.add(list[7]);
            print("url_image : $url_image");
          }
        }

        // layout 2 || 5
        if (choose_layout == "layout 2" || choose_layout == "layout 5") {
          // ......
          // card 1
          // ......
          if (drag_item[0].isNotEmpty) {
            if (drag_item[0].toString().contains("00") &&
                drag_item[0].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("01") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("02") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("03") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[0].toString().contains("10") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("11") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("12") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("13") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 2
          // ......
          if (drag_item[1].isNotEmpty) {
            if (drag_item[1].toString().contains("00") &&
                drag_item[1].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("01") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("02") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("03") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[1].toString().contains("10") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("11") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("12") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("13") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 3
          // ......
          if (drag_item[2].isNotEmpty) {
            if (drag_item[2].toString().contains("00") &&
                drag_item[2].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("01") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("02") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("03") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[2].toString().contains("10") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("11") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("12") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("13") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 4
          // ......
          if (drag_item[3].isNotEmpty) {
            if (drag_item[3].toString().contains("00") &&
                drag_item[3].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("01") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("02") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("03") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[3].toString().contains("10") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("11") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("12") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("13") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }
        }

        // layout 3
        if (choose_layout == "layout 3") {
          // ......
          // card 1
          // ......
          if (drag_item[0].isNotEmpty) {
            if (drag_item[0].toString().contains("00") &&
                drag_item[0].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("01") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("02") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("03") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[0].toString().contains("10") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("11") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("12") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("13") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 2
          // ......
          if (drag_item[1].isNotEmpty) {
            if (drag_item[1].toString().contains("00") &&
                drag_item[1].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("01") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("02") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("03") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[1].toString().contains("10") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("11") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("12") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("13") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 3
          // ......
          if (drag_item[2].isNotEmpty) {
            if (drag_item[2].toString().contains("00") &&
                drag_item[2].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("01") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("02") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("03") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[2].toString().contains("10") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("11") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("12") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("13") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 4
          // ......
          if (drag_item[3].isNotEmpty) {
            if (drag_item[3].toString().contains("00") &&
                drag_item[3].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("01") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("02") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("03") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[3].toString().contains("10") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("11") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("12") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("13") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 5
          // ......
          if (drag_item[4].isNotEmpty) {
            if (drag_item[4].toString().contains("00") &&
                drag_item[4].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("01") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("02") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("03") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[4].toString().contains("10") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("11") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("12") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("13") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }
        }

        // layout 4
        if (choose_layout == "layout 4" || choose_layout == "layout 6") {
          // ......
          // card 1
          // ......
          if (drag_item[0].isNotEmpty) {
            if (drag_item[0].toString().contains("00") &&
                drag_item[0].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("01") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("02") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("03") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[0].toString().contains("10") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("11") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("12") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[0].toString().contains("13") &&
                drag_item[0].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 2
          // ......
          if (drag_item[1].isNotEmpty) {
            if (drag_item[1].toString().contains("00") &&
                drag_item[1].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("01") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("02") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("03") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[1].toString().contains("10") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("11") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("12") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[1].toString().contains("13") &&
                drag_item[1].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 3
          // ......
          if (drag_item[2].isNotEmpty) {
            if (drag_item[2].toString().contains("00") &&
                drag_item[2].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("01") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("02") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("03") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[2].toString().contains("10") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("11") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("12") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[2].toString().contains("13") &&
                drag_item[2].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 4
          // ......
          if (drag_item[3].isNotEmpty) {
            if (drag_item[3].toString().contains("00") &&
                drag_item[3].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("01") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("02") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("03") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[3].toString().contains("10") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("11") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("12") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[3].toString().contains("13") &&
                drag_item[3].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 5
          // ......
          if (drag_item[4].isNotEmpty) {
            if (drag_item[4].toString().contains("00") &&
                drag_item[4].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("01") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("02") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("03") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[4].toString().contains("10") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("11") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("12") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[4].toString().contains("13") &&
                drag_item[4].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 6
          // ......
          if (drag_item[5].isNotEmpty) {
            if (drag_item[5].toString().contains("00") &&
                drag_item[5].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[5].toString().contains("01") &&
                drag_item[5].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[5].toString().contains("02") &&
                drag_item[5].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[5].toString().contains("03") &&
                drag_item[5].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[5].toString().contains("10") &&
                drag_item[5].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[5].toString().contains("11") &&
                drag_item[5].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[5].toString().contains("12") &&
                drag_item[5].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[5].toString().contains("13") &&
                drag_item[5].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 7
          // ......
          if (drag_item[6].isNotEmpty) {
            if (drag_item[6].toString().contains("00") &&
                drag_item[6].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[6].toString().contains("01") &&
                drag_item[6].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[6].toString().contains("02") &&
                drag_item[6].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[6].toString().contains("03") &&
                drag_item[6].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[6].toString().contains("10") &&
                drag_item[6].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[6].toString().contains("11") &&
                drag_item[6].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[6].toString().contains("12") &&
                drag_item[6].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[6].toString().contains("13") &&
                drag_item[6].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 8
          // ......
          if (drag_item[7].isNotEmpty) {
            if (drag_item[7].toString().contains("00") &&
                drag_item[7].toString().isNotEmpty) {
              url_image_b1.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item[7].toString().contains("01") &&
                drag_item[7].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item[7].toString().contains("02") &&
                drag_item[7].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item[7].toString().contains("03") &&
                drag_item[7].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item[7].toString().contains("10") &&
                drag_item[7].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item[7].toString().contains("11") &&
                drag_item[7].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item[7].toString().contains("12") &&
                drag_item[7].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item[7].toString().contains("13") &&
                drag_item[7].toString().isNotEmpty) {
              // ...
              url_image_b1.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 9
          // ......
          if (choose_layout == "layout 6") {
            // ...
            if (drag_item[8].isNotEmpty) {
              if (drag_item[8].toString().contains("00") &&
                  drag_item[8].toString().isNotEmpty) {
                url_image_b1.add(list[0]);
                print("url_image : $url_image");
              }
              if (drag_item[8].toString().contains("01") &&
                  drag_item[8].toString().isNotEmpty) {
                // ...
                url_image_b1.add(list[1]);
                print("url_image : $url_image");
              }
              if (drag_item[8].toString().contains("02") &&
                  drag_item[8].toString().isNotEmpty) {
                // ...
                url_image_b1.add(list[2]);
                print("url_image : $url_image");
              }
              if (drag_item[8].toString().contains("03") &&
                  drag_item[8].toString().isNotEmpty) {
                // ...
                url_image_b1.add(list[3]);
                print("url_image : $url_image");
              }

              if (drag_item[8].toString().contains("10") &&
                  drag_item[8].toString().isNotEmpty) {
                // ...
                url_image_b1.add(list[4]);
                print("url_image : $url_image");
              }
              if (drag_item[8].toString().contains("11") &&
                  drag_item[8].toString().isNotEmpty) {
                // ...
                url_image_b1.add(list[5]);
                print("url_image : $url_image");
              }
              if (drag_item[8].toString().contains("12") &&
                  drag_item[8].toString().isNotEmpty) {
                // ...
                url_image_b1.add(list[6]);
                print("url_image : $url_image");
              }
              if (drag_item[8].toString().contains("13") &&
                  drag_item[8].toString().isNotEmpty) {
                // ...
                url_image_b1.add(list[7]);
                print("url_image : $url_image");
              }
            }
          }
        }

        // ===========================================
        // ============== layout b 2 =================
        // ===========================================

        // layout 1
        if (choose_layout2 == "layout 1") {
          // ......
          // card 1
          // ......
          if (drag_item[0].isNotEmpty) {
            if (drag_item2[0].toString().contains("00") &&
                drag_item2[0].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("01") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("02") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("03") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[0].toString().contains("10") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("11") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("12") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("13") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 2
          // ......
          if (drag_item2[1].isNotEmpty) {
            if (drag_item2[1].toString().contains("00") &&
                drag_item2[1].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("01") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("02") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("03") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[1].toString().contains("10") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("11") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("12") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("13") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 3
          // ......
          if (drag_item2[2].isNotEmpty) {
            if (drag_item2[2].toString().contains("00") &&
                drag_item2[2].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("01") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("02") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("03") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[2].toString().contains("10") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("11") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("12") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("13") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 4
          // ......
          if (drag_item2[3].isNotEmpty) {
            if (drag_item2[3].toString().contains("00") &&
                drag_item2[3].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("01") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("02") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("03") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[3].toString().contains("10") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("11") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("12") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("13") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 5
          // ......
          if (drag_item2[4].isNotEmpty) {
            if (drag_item2[4].toString().contains("00") &&
                drag_item2[4].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("01") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("02") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("03") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[4].toString().contains("10") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("11") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("12") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("13") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }

            // ......
            // card 6
            // ......
            if (drag_item2[5].toString().contains("00") &&
                drag_item2[5].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("01") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("02") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("03") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[5].toString().contains("10") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("11") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("12") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("13") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 6
          // ......
          if (drag_item2[5].isNotEmpty) {
            if (drag_item2[5].toString().contains("00") &&
                drag_item2[5].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("01") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("02") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("03") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[5].toString().contains("10") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("11") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("12") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("13") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }
        }

        // layout 2
        if (choose_layout2 == "layout 2" || choose_layout2 == "layout 5") {
          // ......
          // card 1
          // ......
          if (drag_item2[0].isNotEmpty) {
            if (drag_item2[0].toString().contains("00") &&
                drag_item2[0].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("01") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("02") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("03") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[0].toString().contains("10") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("11") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("12") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("13") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 2
          // ......
          if (drag_item2[1].isNotEmpty) {
            if (drag_item2[1].toString().contains("00") &&
                drag_item2[1].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("01") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("02") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("03") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[1].toString().contains("10") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("11") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("12") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("13") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 3
          // ......
          if (drag_item2[2].isNotEmpty) {
            if (drag_item2[2].toString().contains("00") &&
                drag_item2[2].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("01") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("02") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("03") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[2].toString().contains("10") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("11") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("12") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("13") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 4
          // ......
          if (drag_item2[3].isNotEmpty) {
            if (drag_item2[3].toString().contains("00") &&
                drag_item2[3].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("01") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("02") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("03") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[3].toString().contains("10") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("11") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("12") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("13") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }
        }

        // layout 3
        if (choose_layout2 == "layout 3") {
          // ......
          // card 1
          // ......
          if (drag_item2[0].isNotEmpty) {
            if (drag_item2[0].toString().contains("00") &&
                drag_item2[0].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("01") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("02") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("03") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[0].toString().contains("10") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("11") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("12") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("13") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 2
          // ......
          if (drag_item2[1].isNotEmpty) {
            if (drag_item2[1].toString().contains("00") &&
                drag_item2[1].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("01") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("02") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("03") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[1].toString().contains("10") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("11") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("12") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("13") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 3
          // ......
          if (drag_item2[2].isNotEmpty) {
            if (drag_item2[2].toString().contains("00") &&
                drag_item2[2].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("01") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("02") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("03") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[2].toString().contains("10") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("11") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("12") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("13") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 4
          // ......
          if (drag_item2[3].isNotEmpty) {
            if (drag_item2[3].toString().contains("00") &&
                drag_item2[3].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("01") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("02") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("03") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[3].toString().contains("10") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("11") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("12") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("13") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 5
          // ......
          if (drag_item2[4].isNotEmpty) {
            if (drag_item2[4].toString().contains("00") &&
                drag_item2[4].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("01") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("02") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("03") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[4].toString().contains("10") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("11") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("12") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("13") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }
        }

        // layout 4 dan 6
        if (choose_layout2 == "layout 4" || choose_layout == "layout 6") {
          // ......
          // card 1
          // ......
          if (drag_item2[0].isNotEmpty) {
            if (drag_item2[0].toString().contains("00") &&
                drag_item2[0].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("01") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("02") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("03") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[0].toString().contains("10") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("11") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("12") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[0].toString().contains("13") &&
                drag_item2[0].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 2
          // ......
          if (drag_item2[1].isNotEmpty) {
            if (drag_item2[1].toString().contains("00") &&
                drag_item2[1].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("01") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("02") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("03") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[1].toString().contains("10") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("11") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("12") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[1].toString().contains("13") &&
                drag_item2[1].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 3
          // ......
          if (drag_item2[2].isNotEmpty) {
            if (drag_item2[2].toString().contains("00") &&
                drag_item2[2].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("01") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("02") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("03") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[2].toString().contains("10") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("11") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("12") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[2].toString().contains("13") &&
                drag_item2[2].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 4
          // ......
          if (drag_item2[3].isNotEmpty) {
            if (drag_item2[3].toString().contains("00") &&
                drag_item2[3].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("01") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("02") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("03") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[3].toString().contains("10") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("11") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("12") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[3].toString().contains("13") &&
                drag_item2[3].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 5
          // ......
          if (drag_item2[4].isNotEmpty) {
            if (drag_item2[4].toString().contains("00") &&
                drag_item2[4].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("01") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("02") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("03") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[4].toString().contains("10") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("11") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("12") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[4].toString().contains("13") &&
                drag_item2[4].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }

            // ......
            // card 6
            // ......
            if (drag_item2[5].toString().contains("00") &&
                drag_item2[5].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("01") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("02") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("03") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[5].toString().contains("10") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("11") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("12") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("13") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 6
          // ......
          if (drag_item2[5].isNotEmpty) {
            if (drag_item2[5].toString().contains("00") &&
                drag_item2[5].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("01") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("02") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("03") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[5].toString().contains("10") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("11") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("12") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[5].toString().contains("13") &&
                drag_item2[5].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 7
          // ......
          if (drag_item2[6].isNotEmpty) {
            if (drag_item2[6].toString().contains("00") &&
                drag_item2[6].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[6].toString().contains("01") &&
                drag_item2[6].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[6].toString().contains("02") &&
                drag_item2[6].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[6].toString().contains("03") &&
                drag_item2[6].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[6].toString().contains("10") &&
                drag_item2[6].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[6].toString().contains("11") &&
                drag_item2[6].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[6].toString().contains("12") &&
                drag_item2[6].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[6].toString().contains("13") &&
                drag_item2[6].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 8
          // ......
          if (drag_item2[7].isNotEmpty) {
            if (drag_item2[7].toString().contains("00") &&
                drag_item2[7].toString().isNotEmpty) {
              url_image_b2.add(list[0]);
              print("url_image : $url_image");
            }
            if (drag_item2[7].toString().contains("01") &&
                drag_item2[7].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[1]);
              print("url_image : $url_image");
            }
            if (drag_item2[7].toString().contains("02") &&
                drag_item2[7].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[2]);
              print("url_image : $url_image");
            }
            if (drag_item2[7].toString().contains("03") &&
                drag_item2[7].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[3]);
              print("url_image : $url_image");
            }

            if (drag_item2[7].toString().contains("10") &&
                drag_item2[7].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[4]);
              print("url_image : $url_image");
            }
            if (drag_item2[7].toString().contains("11") &&
                drag_item2[7].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[5]);
              print("url_image : $url_image");
            }
            if (drag_item2[7].toString().contains("12") &&
                drag_item2[7].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[6]);
              print("url_image : $url_image");
            }
            if (drag_item2[7].toString().contains("13") &&
                drag_item2[7].toString().isNotEmpty) {
              // ...
              url_image_b2.add(list[7]);
              print("url_image : $url_image");
            }
          }

          // ......
          // card 9
          // ......
          if (choose_layout2 == "layout 6") {
            if (drag_item2[8].isNotEmpty) {
              if (drag_item2[8].toString().contains("00") &&
                  drag_item2[8].toString().isNotEmpty) {
                url_image_b2.add(list[0]);
                print("url_image : $url_image");
              }
              if (drag_item2[8].toString().contains("01") &&
                  drag_item2[8].toString().isNotEmpty) {
                // ...
                url_image_b2.add(list[1]);
                print("url_image : $url_image");
              }
              if (drag_item2[8].toString().contains("02") &&
                  drag_item2[8].toString().isNotEmpty) {
                // ...
                url_image_b2.add(list[2]);
                print("url_image : $url_image");
              }
              if (drag_item2[8].toString().contains("03") &&
                  drag_item2[8].toString().isNotEmpty) {
                // ...
                url_image_b2.add(list[3]);
                print("url_image : $url_image");
              }

              if (drag_item2[8].toString().contains("10") &&
                  drag_item2[8].toString().isNotEmpty) {
                // ...
                url_image_b2.add(list[4]);
                print("url_image : $url_image");
              }
              if (drag_item2[8].toString().contains("11") &&
                  drag_item2[8].toString().isNotEmpty) {
                // ...
                url_image_b2.add(list[5]);
                print("url_image : $url_image");
              }
              if (drag_item2[8].toString().contains("12") &&
                  drag_item2[8].toString().isNotEmpty) {
                // ...
                url_image_b2.add(list[6]);
                print("url_image : $url_image");
              }
              if (drag_item2[8].toString().contains("13") &&
                  drag_item2[8].toString().isNotEmpty) {
                // ...
                url_image_b2.add(list[7]);
                print("url_image : $url_image");
              }
            }
          }
        }
      }

      // ..........................................
      if (title.toString().contains("Collage A") ||
          title.toString().contains("Paket A")) {
        if (list.isNotEmpty) {
          if (drag_item.isNotEmpty) {
            // layout 1 dan 2
            if (choose_layout == "layout 1") {
              // ......
              // card 1
              // ......
              if (drag_item[0].toString().contains("00") &&
                  drag_item[0].toString().isNotEmpty) {
                url_image.add(list[0]);
                print("url_image : $url_image");
              }
              if (drag_item[0].toString().contains("01") &&
                  drag_item[0].toString().isNotEmpty) {
                // ...
                url_image.add(list[1]);
                print("url_image : $url_image");
              }
              if (drag_item[0].toString().contains("02") &&
                  drag_item[0].toString().isNotEmpty) {
                // ...
                url_image.add(list[2]);
                print("url_image : $url_image");
              }

              if (drag_item[0].toString().contains("10") &&
                  drag_item[0].toString().isNotEmpty) {
                // ...
                url_image.add(list[3]);
                print("url_image : $url_image");
              }
              if (drag_item[0].toString().contains("11") &&
                  drag_item[0].toString().isNotEmpty) {
                // ...
                url_image.add(list[4]);
                print("url_image : $url_image");
              }
              if (drag_item[0].toString().contains("12") &&
                  drag_item[0].toString().isNotEmpty) {
                // ...
                url_image.add(list[5]);
                print("url_image : $url_image");
              }
            }

            // layout 2
            if (choose_layout == "layout 2") {
              // ......
              // card 1
              // ......
              if (drag_item[0].isNotEmpty) {
                if (drag_item[0].toString().contains("00") &&
                    drag_item[0].toString().isNotEmpty) {
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("01") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("02") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }

                if (list[3].toString().isNotEmpty &&
                    drag_item[0].toString().contains("10") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (list[4].toString().isNotEmpty &&
                    drag_item[0].toString().contains("11") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (list[5].toString().isNotEmpty &&
                    drag_item[0].toString().contains("12") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }

              // ......
              // card 2
              // ......
              if (drag_item[1].isNotEmpty) {
                if (drag_item[1].toString().contains("00") &&
                    drag_item[1].toString().isNotEmpty) {
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("01") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("02") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (list[3].toString().isNotEmpty &&
                    drag_item[1].toString().contains("10") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (list[4].toString().isNotEmpty &&
                    drag_item[1].toString().contains("11") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (list[5].toString().isNotEmpty &&
                    drag_item[1].toString().contains("12") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }
            }

            // layout 3
            if (choose_layout == "layout 3") {
              // ......
              // card 1
              // ......

              if (drag_item[0].isNotEmpty) {
                if (drag_item[0].toString().contains("00") &&
                    drag_item[0].toString().isNotEmpty) {
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("01") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("02") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }

                if (list[3].toString().isNotEmpty &&
                    drag_item[0].toString().contains("10") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (list[4].toString().isNotEmpty &&
                    drag_item[0].toString().contains("11") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (list[5].toString().isNotEmpty &&
                    drag_item[0].toString().contains("12") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }

              // ......
              // card 2
              // ......
              if (drag_item[1].isNotEmpty) {
                if (drag_item[1].toString().contains("00") &&
                    drag_item[1].toString().isNotEmpty) {
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("01") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("02") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (list[3].toString().isNotEmpty &&
                    drag_item[1].toString().contains("10") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (list[4].toString().isNotEmpty &&
                    drag_item[1].toString().contains("11") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (list[5].toString().isNotEmpty &&
                    drag_item[1].toString().contains("12") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }
            }

            // layout 4
            if (choose_layout == "layout 4") {
              // ......
              // card 1
              // ......
              if (drag_item[0].isNotEmpty) {
                if (drag_item[0].toString().contains("00") &&
                    drag_item[0].toString().isNotEmpty) {
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("01") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("02") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("10") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("11") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("12") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }

              // ......
              // card 2
              // ......
              if (drag_item[1].isNotEmpty) {
                if (drag_item[1].toString().contains("00") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("01") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("02") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("10") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("11") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("12") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }

              // ......
              // card 3
              // ......
              if (drag_item[2].isNotEmpty) {
                if (drag_item[2].toString().contains("00") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("01") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("02") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("10") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("11") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("12") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }
            }

            // layout 5
            if (choose_layout == "layout 5") {
              // ......
              // card 1
              // ......
              if (drag_item[0].isNotEmpty) {
                if (drag_item[0].toString().contains("00") &&
                    drag_item[0].toString().isNotEmpty) {
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("01") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("02") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("10") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("11") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("12") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }

              // ......
              // card 2
              // ......
              if (drag_item[1].isNotEmpty) {
                if (drag_item[1].toString().contains("00") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("01") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("02") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("10") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("11") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("12") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }

              // ......
              // card 3
              // ......
              if (drag_item[2].isNotEmpty) {
                if (drag_item[2].toString().contains("00") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("01") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("02") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("10") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("11") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("12") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }
            }

            // layout 4
            if (choose_layout == "layout 6") {
              // ......
              // card 1
              // ......
              if (drag_item[0].isNotEmpty) {
                if (drag_item[0].toString().contains("00") &&
                    drag_item[0].toString().isNotEmpty) {
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("01") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("02") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("10") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("11") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (drag_item[0].toString().contains("12") &&
                    drag_item[0].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }

              // ......
              // card 2
              // ......
              if (drag_item[1].isNotEmpty) {
                if (drag_item[1].toString().contains("00") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("01") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("02") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("10") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("11") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (drag_item[1].toString().contains("12") &&
                    drag_item[1].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }

              // ......
              // card 3
              // ......
              if (drag_item[2].isNotEmpty) {
                if (drag_item[2].toString().contains("00") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("01") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("02") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("10") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("11") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (drag_item[2].toString().contains("12") &&
                    drag_item[2].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }

              // ......
              // card 4
              // ......
              if (drag_item[3].isNotEmpty) {
                if (drag_item[3].toString().contains("00") &&
                    drag_item[3].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[0]);
                  print("url_image : $url_image");
                }
                if (drag_item[3].toString().contains("01") &&
                    drag_item[3].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[1]);
                  print("url_image : $url_image");
                }
                if (drag_item[3].toString().contains("02") &&
                    drag_item[3].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[2]);
                  print("url_image : $url_image");
                }
                if (drag_item[3].toString().contains("10") &&
                    drag_item[3].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[3]);
                  print("url_image : $url_image");
                }
                if (drag_item[3].toString().contains("11") &&
                    drag_item[3].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[4]);
                  print("url_image : $url_image");
                }
                if (drag_item[3].toString().contains("12") &&
                    drag_item[3].toString().isNotEmpty) {
                  // ...
                  url_image.add(list[5]);
                  print("url_image : $url_image");
                }
              }
            }
          }
        }
      }
    } else {
      print(response.reasonPhrase);
    }
  }

  void filterBeauty() async {
    setState(() {
      isFilterBeauty = !isFilterBeauty;
    });
  }

  @override
  // Size get preferredSize => const Size.fromHeight(kToolbarHeight + 100.0);
  Widget build(BuildContext context) {
    // ...
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Material(
      child: Container(
        decoration: backgrounds != null
            ? BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(
                      "${Variables.ipv4_local}/storage/order/background-image/$backgrounds"),
                  fit: BoxFit.cover,
                ),
              )
            : BoxDecoration(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // ----------------
            // header page view
            // ----------------
            Container(
              height: height * 0.12,
              width: width * 1,
              child: Column(
                children: [
                  Container(
                      height: width * 0.012,
                      width: width * 1,
                      color: bg_warna_main != ""
                          ? HexColor(bg_warna_main).withOpacity(0.7)
                          : Colors.transparent),
                  Container(
                    height: width * 0.035,
                    width: width * 1,
                    color: bg_warna_main != ""
                        ? HexColor(bg_warna_main).withOpacity(0.7)
                        : Colors.transparent,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Filter",
                          style: TextStyle(
                            fontSize: width * 0.022,
                            color: Colors.white,
                            fontWeight: FontWeight.normal,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Icon(
                          Icons.arrow_right,
                          size: 25,
                          color: Colors.white,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Layout",
                          style: TextStyle(
                            fontSize: width * 0.022,
                            color: Colors.white,
                            fontWeight: FontWeight.normal,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Icon(
                          Icons.arrow_right,
                          size: 25,
                          color: Colors.white,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Background",
                          style: TextStyle(
                            fontSize: width * 0.022,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Icon(
                          Icons.arrow_right,
                          size: 25,
                          color: Colors.white,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Sticker",
                          style: TextStyle(
                            fontSize: width * 0.022,
                            color: Colors.white,
                            fontWeight: FontWeight.normal,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: height * 0.025,
                    width: width * 1,
                    child: WaveWidget(
                      config: CustomConfig(
                        colors: [
                          warna1 != "" ? HexColor(warna1) : Colors.transparent,
                          warna2 != ""
                              ? HexColor(warna2).withOpacity(0.7)
                              : Colors.transparent
                        ],
                        durations: _durations,
                        heightPercentages: _heightPercentages,
                      ),
                      backgroundColor: bg_warna_main != ""
                          ? HexColor(bg_warna_main).withOpacity(0.7)
                          : Colors.transparent,
                      size: Size(double.infinity, double.infinity),
                      waveAmplitude: 0,
                    ),
                  ),
                ],
              ),
            ),
            // ---------------------
            // end header page view
            // ---------------------

            // --------------------------
            // body page view filter page
            // --------------------------
            Container(
              width: width * 1,
              height: height * 0.88,

              // ...............
              // Row Main Layout
              // ...............
              child: Row(
                children: [
                  // ..........................................
                  // Start - Component Kiri Layout Pilih Kanvas
                  // ..........................................
                  Container(
                    width: width * 0.25,
                    color: bg_warna_main != ""
                        ? HexColor(bg_warna_main).withOpacity(0.7)
                        : Colors.transparent,
                    child: Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                            top: width * 0.025,
                            bottom: width * 0.0,
                          ),
                          child: Text(
                            "Pilih Kanvas",
                            style: TextStyle(
                              fontSize: width * 0.025,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),

                        // kanvas card component kanan
                        Padding(
                          padding: EdgeInsets.only(top: width * 0.0025),
                          child: Padding(
                            padding: EdgeInsets.all(
                              width * 0.012,
                            ),
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                color: Colors.transparent,
                                boxShadow: [
                                  const BoxShadow(
                                    color: Colors.transparent,
                                    spreadRadius: 5,
                                  ),
                                ],
                              ),
                              height: height * 0.25,
                              width: width * 0.375,

                              // ===========================================================================================
                              // ========== row pilih kanvas menu tengah kecil, A dan B fix 1 dan 2 menu ===================
                              // ===========================================================================================
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children:
                                    title.toString().contains("Collage A") ||
                                            title.toString().contains("Paket A")
                                        ? [
                                            // ...
                                            // tipe collage a atau strip a
                                            // ...

                                            // Layout 1 A, Kecil Atas
                                            choose_layout == "layout 1" &&
                                                    url_image.isNotEmpty
                                                ? Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            12.0),
                                                    child: InkWell(
                                                      onTap: () async {
                                                        // ---
                                                      },
                                                      child: Container(
                                                        width: width * 0.0925,
                                                        height: height * 0.23,
                                                        decoration:
                                                            choose_background !=
                                                                    ""
                                                                ? BoxDecoration(
                                                                    image:
                                                                        DecorationImage(
                                                                      // last visit code here
                                                                      image: NetworkImage(
                                                                          "${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                      fit: BoxFit
                                                                          .cover,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(5),
                                                                    color: Colors
                                                                        .white,
                                                                  )
                                                                : BoxDecoration(
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(5),
                                                                    color: Colors
                                                                        .black
                                                                        .withOpacity(
                                                                            0.7),
                                                                  ),
                                                        child: Column(
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.01,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.0725,
                                                                height: width *
                                                                    0.0725,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              5),
                                                                  color: Colors
                                                                      .white,
                                                                  image:
                                                                      DecorationImage(
                                                                    image:
                                                                        NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/${url_image[0].toString()}",
                                                                      scale: 1,
                                                                    ),
                                                                    fit: BoxFit
                                                                        .contain,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                :

                                                // Layout 2 A, Kecil Atas
                                                choose_layout == "layout 2" &&
                                                        url_image.isNotEmpty
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(12.0),
                                                        child: InkWell(
                                                          onTap: () async {
                                                            // ---
                                                          },
                                                          child: Container(
                                                            width:
                                                                width * 0.0925,
                                                            height:
                                                                height * 0.23,
                                                            decoration:
                                                                choose_background !=
                                                                        ""
                                                                    ? BoxDecoration(
                                                                        image:
                                                                            DecorationImage(
                                                                          // last visit code here
                                                                          image:
                                                                              NetworkImage("${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                          fit: BoxFit
                                                                              .cover,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .white,
                                                                      )
                                                                    : BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .black
                                                                            .withOpacity(0.7),
                                                                      ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0,
                                                              ),
                                                              child:
                                                                  // .................................
                                                                  // layout row drag target main view
                                                                  // .................................
                                                                  Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                children: [
                                                                  // .............................
                                                                  // layout drag target main view
                                                                  // .............................

                                                                  // ============
                                                                  // kolom card 0
                                                                  Container(
                                                                    width: width *
                                                                        0.035,
                                                                    height:
                                                                        width *
                                                                            0.035,
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0,
                                                                      ),
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.035,
                                                                        height: width *
                                                                            0.035,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(10),
                                                                          image:
                                                                              DecorationImage(
                                                                            image:
                                                                                NetworkImage(
                                                                              "${Variables.ipv4_local}/storage/${url_image[0].toString()}",
                                                                              scale: 1,
                                                                            ),
                                                                            fit:
                                                                                BoxFit.cover,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      // ),
                                                                    ),
                                                                  ),

                                                                  // ============
                                                                  // kolom card 1
                                                                  Container(
                                                                    width: width *
                                                                        0.035,
                                                                    height:
                                                                        width *
                                                                            0.035,
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0,
                                                                      ),
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.035,
                                                                        height: width *
                                                                            0.035,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(10),
                                                                          image:
                                                                              DecorationImage(
                                                                            image:
                                                                                NetworkImage(
                                                                              "${Variables.ipv4_local}/storage/${url_image[1].toString()}",
                                                                              scale: 1,
                                                                            ),
                                                                            fit:
                                                                                BoxFit.cover,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      // ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    :

                                                    // Layout 3 A, Kecil Atas
                                                    choose_layout ==
                                                                "layout 3" &&
                                                            url_image.isNotEmpty
                                                        ? Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(12.0),
                                                            child: InkWell(
                                                              onTap: () async {
                                                                // ---
                                                              },
                                                              child: Container(
                                                                width: width *
                                                                    0.092,
                                                                height: height *
                                                                    0.23,
                                                                decoration:
                                                                    choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                child: Padding(
                                                                  padding:
                                                                      EdgeInsets
                                                                          .all(
                                                                    width * 0.0,
                                                                  ),
                                                                  child: Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceEvenly,
                                                                        children: [
                                                                          // ---
                                                                          Container(
                                                                            width:
                                                                                width * 0.042,
                                                                            height:
                                                                                width * 0.042,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.042,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image[0].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            width:
                                                                                width * 0.042,
                                                                            height:
                                                                                width * 0.042,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.042,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image[1].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          )
                                                        :

                                                        // Layout 4 A, Kecil Atas
                                                        choose_layout ==
                                                                    "layout 4" &&
                                                                url_image
                                                                    .isNotEmpty
                                                            ? Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        12.0),
                                                                child: InkWell(
                                                                  onTap:
                                                                      () async {
                                                                    // ---
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    width: width *
                                                                        0.092,
                                                                    height:
                                                                        height *
                                                                            0.24,
                                                                    decoration: choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(15),
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0025,
                                                                      ),
                                                                      child:
                                                                          Row(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceEvenly,
                                                                        children: [
                                                                          // .............................
                                                                          // layout drag target main view
                                                                          // .............................

                                                                          // ============
                                                                          // kolom card 0
                                                                          Container(
                                                                            width:
                                                                                width * 0.025,
                                                                            height:
                                                                                width * 0.025,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.034,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image[0].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),

                                                                          // ============
                                                                          // kolom card 1
                                                                          Container(
                                                                            width:
                                                                                width * 0.025,
                                                                            height:
                                                                                width * 0.025,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.034,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image[1].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),

                                                                          Container(
                                                                            width:
                                                                                width * 0.025,
                                                                            height:
                                                                                width * 0.025,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.034,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image[2].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              )
                                                            :

                                                            // Layout 5 A, Kecil Atas
                                                            choose_layout ==
                                                                        "layout 5" &&
                                                                    url_image
                                                                        .isNotEmpty
                                                                ? Padding(
                                                                    padding:
                                                                        const EdgeInsets
                                                                            .all(
                                                                            12.0),
                                                                    child:
                                                                        InkWell(
                                                                      onTap:
                                                                          () async {
                                                                        // ---
                                                                      },
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: height *
                                                                            0.23,
                                                                        decoration: choose_background !=
                                                                                ""
                                                                            ? BoxDecoration(
                                                                                image: DecorationImage(
                                                                                  // last visit code here
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                                borderRadius: BorderRadius.circular(5),
                                                                                color: Colors.white,
                                                                              )
                                                                            : BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(5),
                                                                                color: Colors.black.withOpacity(0.7),
                                                                              ),
                                                                        child:
                                                                            Padding(
                                                                          padding:
                                                                              EdgeInsets.all(
                                                                            width *
                                                                                0.0,
                                                                          ),
                                                                          child:
                                                                              Column(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.spaceEvenly,
                                                                            children: [
                                                                              // .............................
                                                                              // layout drag target main view
                                                                              // .............................

                                                                              // ============
                                                                              // kolom card 0
                                                                              Container(
                                                                                width: width * 0.035,
                                                                                height: width * 0.035,
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(
                                                                                    width * 0.0,
                                                                                  ),
                                                                                  child: Container(
                                                                                    width: width * 0.035,
                                                                                    height: width * 0.035,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      image: DecorationImage(
                                                                                        image: NetworkImage(
                                                                                          "${Variables.ipv4_local}/storage/${url_image[0].toString()}",
                                                                                          scale: 1,
                                                                                        ),
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  // ),
                                                                                ),
                                                                              ),

                                                                              // ============
                                                                              // kolom card 1
                                                                              Container(
                                                                                width: width * 0.035,
                                                                                height: width * 0.035,
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(
                                                                                    width * 0.0,
                                                                                  ),
                                                                                  child: Container(
                                                                                    width: width * 0.035,
                                                                                    height: width * 0.035,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      image: DecorationImage(
                                                                                        image: NetworkImage(
                                                                                          "${Variables.ipv4_local}/storage/${url_image[1].toString()}",
                                                                                          scale: 1,
                                                                                        ),
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  // ),
                                                                                ),
                                                                              ),

                                                                              // ============
                                                                              // kolom card 2
                                                                              Container(
                                                                                width: width * 0.035,
                                                                                height: width * 0.035,
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(
                                                                                    width * 0.0,
                                                                                  ),
                                                                                  child: Container(
                                                                                    width: width * 0.035,
                                                                                    height: width * 0.035,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      image: DecorationImage(
                                                                                        image: NetworkImage(
                                                                                          "${Variables.ipv4_local}/storage/${url_image[2].toString()}",
                                                                                          scale: 1,
                                                                                        ),
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  )
                                                                :

                                                                // Layout 6 A, Kecil Atas
                                                                choose_layout ==
                                                                            "layout 6" &&
                                                                        url_image
                                                                            .isNotEmpty
                                                                    ? Padding(
                                                                        padding: const EdgeInsets
                                                                            .all(
                                                                            12.0),
                                                                        child:
                                                                            InkWell(
                                                                          onTap:
                                                                              () async {
                                                                            // ---
                                                                          },
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.0925,
                                                                            height:
                                                                                height * 0.23,
                                                                            decoration: choose_background != ""
                                                                                ? BoxDecoration(
                                                                                    image: DecorationImage(
                                                                                      // last visit code here
                                                                                      image: NetworkImage("${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                                      fit: BoxFit.cover,
                                                                                    ),
                                                                                    borderRadius: BorderRadius.circular(5),
                                                                                    color: Colors.white,
                                                                                  )
                                                                                : BoxDecoration(
                                                                                    borderRadius: BorderRadius.circular(5),
                                                                                    color: Colors.black.withOpacity(0.7),
                                                                                  ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0025,
                                                                              ),
                                                                              child: Row(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .................................
                                                                                  // layout row drag target main view
                                                                                  // .................................
                                                                                  Column(
                                                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                    children: [
                                                                                      // .............................
                                                                                      // layout drag target main view
                                                                                      // .............................

                                                                                      // ============
                                                                                      // kolom card 0
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image[0].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          // ),
                                                                                        ),
                                                                                      ),

                                                                                      // ============
                                                                                      // kolom card 1
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image[1].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),

                                                                                  Column(
                                                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                    children: [
                                                                                      // .............................
                                                                                      // layout drag target main view
                                                                                      // .............................

                                                                                      // ============
                                                                                      // kolom card 2
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image[2].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          // ),
                                                                                        ),
                                                                                      ),

                                                                                      // ============
                                                                                      // kolom card 3
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image[3].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          // ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      )
                                                                    : choose_layout ==
                                                                                "layout 7" &&
                                                                            url_image
                                                                                .isNotEmpty
                                                                        ? Padding(
                                                                            padding:
                                                                                const EdgeInsets.all(12.0),
                                                                            child:
                                                                                InkWell(
                                                                              onTap: () async {
                                                                                // ---
                                                                              },
                                                                              child: Container(
                                                                                width: width * 0.092,
                                                                                height: height * 0.23,
                                                                                decoration: choose_background != ""
                                                                                    ? BoxDecoration(
                                                                                        image: DecorationImage(
                                                                                          // last visit code here
                                                                                          image: NetworkImage("${Variables.ipv4_local}/storage/background-image/edit-photo/${choose_background.toString()}"),
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                        borderRadius: BorderRadius.circular(5),
                                                                                        color: Colors.white,
                                                                                      )
                                                                                    : BoxDecoration(
                                                                                        borderRadius: BorderRadius.circular(5),
                                                                                        color: Colors.black.withOpacity(0.7),
                                                                                      ),
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(
                                                                                    width * 0.0,
                                                                                  ),
                                                                                  child: Row(
                                                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                    children: [
                                                                                      Column(
                                                                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                        children: [
                                                                                          // ---
                                                                                          Container(
                                                                                            width: width * 0.025,
                                                                                            height: width * 0.025,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(5),
                                                                                              color: Colors.white,
                                                                                            ),
                                                                                            child: Padding(
                                                                                              padding: EdgeInsets.all(
                                                                                                width * 0.0,
                                                                                              ),
                                                                                              child: Container(
                                                                                                width: width * 0.034,
                                                                                                height: width * 0.042,
                                                                                                decoration: BoxDecoration(
                                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                                  image: DecorationImage(
                                                                                                    image: NetworkImage(
                                                                                                      "${Variables.ipv4_local}/storage/${url_image[0].toString()}",
                                                                                                      scale: 1,
                                                                                                    ),
                                                                                                    fit: BoxFit.cover,
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          Container(
                                                                                            width: width * 0.025,
                                                                                            height: width * 0.025,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(5),
                                                                                              color: Colors.white,
                                                                                            ),
                                                                                            child: Padding(
                                                                                              padding: EdgeInsets.all(
                                                                                                width * 0.0,
                                                                                              ),
                                                                                              child: Container(
                                                                                                width: width * 0.034,
                                                                                                height: width * 0.042,
                                                                                                decoration: BoxDecoration(
                                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                                  image: DecorationImage(
                                                                                                    image: NetworkImage(
                                                                                                      "${Variables.ipv4_local}/storage/${url_image[1].toString()}",
                                                                                                      scale: 1,
                                                                                                    ),
                                                                                                    fit: BoxFit.cover,
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                      Column(
                                                                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                        children: [
                                                                                          // ---
                                                                                          Container(
                                                                                            width: width * 0.025,
                                                                                            height: width * 0.025,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(5),
                                                                                              color: Colors.white,
                                                                                            ),
                                                                                            child: Padding(
                                                                                              padding: EdgeInsets.all(
                                                                                                width * 0.0,
                                                                                              ),
                                                                                              child: Container(
                                                                                                width: width * 0.034,
                                                                                                height: width * 0.042,
                                                                                                decoration: BoxDecoration(
                                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                                  image: DecorationImage(
                                                                                                    image: NetworkImage(
                                                                                                      "${Variables.ipv4_local}/storage/${url_image[2].toString()}",
                                                                                                      scale: 1,
                                                                                                    ),
                                                                                                    fit: BoxFit.cover,
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          Container(
                                                                                            width: width * 0.025,
                                                                                            height: width * 0.025,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(5),
                                                                                              color: Colors.white,
                                                                                            ),
                                                                                            child: Padding(
                                                                                              padding: EdgeInsets.all(
                                                                                                width * 0.0,
                                                                                              ),
                                                                                              child: Container(
                                                                                                width: width * 0.034,
                                                                                                height: width * 0.042,
                                                                                                decoration: BoxDecoration(
                                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                                  image: DecorationImage(
                                                                                                    image: NetworkImage(
                                                                                                      "${Variables.ipv4_local}/storage/${url_image[3].toString()}",
                                                                                                      scale: 1,
                                                                                                    ),
                                                                                                    fit: BoxFit.cover,
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          Container(
                                                                                            width: width * 0.025,
                                                                                            height: width * 0.025,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(5),
                                                                                              color: Colors.white,
                                                                                            ),
                                                                                            child: Padding(
                                                                                              padding: EdgeInsets.all(
                                                                                                width * 0.0,
                                                                                              ),
                                                                                              child: Container(
                                                                                                width: width * 0.034,
                                                                                                height: width * 0.042,
                                                                                                decoration: BoxDecoration(
                                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                                  image: DecorationImage(
                                                                                                    image: NetworkImage(
                                                                                                      "${Variables.ipv4_local}/storage/${url_image[4].toString()}",
                                                                                                      scale: 1,
                                                                                                    ),
                                                                                                    fit: BoxFit.cover,
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          )
                                                                        : choose_layout == "layout 8" &&
                                                                                url_image.isNotEmpty
                                                                            ? Padding(
                                                                                padding: const EdgeInsets.all(12.0),
                                                                                child: InkWell(
                                                                                  onTap: () async {
                                                                                    // ---
                                                                                  },
                                                                                  child: Container(
                                                                                    width: width * 0.092,
                                                                                    height: height * 0.23,
                                                                                    decoration: choose_background != ""
                                                                                        ? BoxDecoration(
                                                                                            image: DecorationImage(
                                                                                              // last visit code here
                                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background-image/edit-photo/${choose_background.toString()}"),
                                                                                              fit: BoxFit.cover,
                                                                                            ),
                                                                                            borderRadius: BorderRadius.circular(5),
                                                                                            color: Colors.white,
                                                                                          )
                                                                                        : BoxDecoration(
                                                                                            borderRadius: BorderRadius.circular(5),
                                                                                            color: Colors.black.withOpacity(0.7),
                                                                                          ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0,
                                                                                      ),
                                                                                      child: Row(
                                                                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                        children: [
                                                                                          Column(
                                                                                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                            children: [
                                                                                              // ---
                                                                                              Container(
                                                                                                width: width * 0.025,
                                                                                                height: width * 0.025,
                                                                                                decoration: BoxDecoration(
                                                                                                  borderRadius: BorderRadius.circular(5),
                                                                                                  color: Colors.white,
                                                                                                ),
                                                                                                child: Padding(
                                                                                                  padding: EdgeInsets.all(
                                                                                                    width * 0.0,
                                                                                                  ),
                                                                                                  child: Container(
                                                                                                    width: width * 0.034,
                                                                                                    height: width * 0.042,
                                                                                                    decoration: BoxDecoration(
                                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                                      image: DecorationImage(
                                                                                                        image: NetworkImage(
                                                                                                          "${Variables.ipv4_local}/storage/${url_image[0].toString()}",
                                                                                                          scale: 1,
                                                                                                        ),
                                                                                                        fit: BoxFit.cover,
                                                                                                      ),
                                                                                                    ),
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                              Container(
                                                                                                width: width * 0.025,
                                                                                                height: width * 0.025,
                                                                                                decoration: BoxDecoration(
                                                                                                  borderRadius: BorderRadius.circular(5),
                                                                                                  color: Colors.white,
                                                                                                ),
                                                                                                child: Padding(
                                                                                                  padding: EdgeInsets.all(
                                                                                                    width * 0.0,
                                                                                                  ),
                                                                                                  child: Container(
                                                                                                    width: width * 0.034,
                                                                                                    height: width * 0.042,
                                                                                                    decoration: BoxDecoration(
                                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                                      image: DecorationImage(
                                                                                                        image: NetworkImage(
                                                                                                          "${Variables.ipv4_local}/storage/${url_image[1].toString()}",
                                                                                                          scale: 1,
                                                                                                        ),
                                                                                                        fit: BoxFit.cover,
                                                                                                      ),
                                                                                                    ),
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            ],
                                                                                          ),
                                                                                          Column(
                                                                                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                            children: [
                                                                                              // ---
                                                                                              Container(
                                                                                                width: width * 0.025,
                                                                                                height: width * 0.025,
                                                                                                decoration: BoxDecoration(
                                                                                                  borderRadius: BorderRadius.circular(5),
                                                                                                  color: Colors.white,
                                                                                                ),
                                                                                                child: Padding(
                                                                                                  padding: EdgeInsets.all(
                                                                                                    width * 0.0,
                                                                                                  ),
                                                                                                  child: Container(
                                                                                                    width: width * 0.034,
                                                                                                    height: width * 0.042,
                                                                                                    decoration: BoxDecoration(
                                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                                      image: DecorationImage(
                                                                                                        image: NetworkImage(
                                                                                                          "${Variables.ipv4_local}/storage/${url_image[2].toString()}",
                                                                                                          scale: 1,
                                                                                                        ),
                                                                                                        fit: BoxFit.cover,
                                                                                                      ),
                                                                                                    ),
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                              Container(
                                                                                                width: width * 0.025,
                                                                                                height: width * 0.025,
                                                                                                decoration: BoxDecoration(
                                                                                                  borderRadius: BorderRadius.circular(5),
                                                                                                  color: Colors.white,
                                                                                                ),
                                                                                                child: Padding(
                                                                                                  padding: EdgeInsets.all(
                                                                                                    width * 0.0,
                                                                                                  ),
                                                                                                  child: Container(
                                                                                                    width: width * 0.034,
                                                                                                    height: width * 0.042,
                                                                                                    decoration: BoxDecoration(
                                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                                      image: DecorationImage(
                                                                                                        image: NetworkImage(
                                                                                                          "${Variables.ipv4_local}/storage/${url_image[3].toString()}",
                                                                                                          scale: 1,
                                                                                                        ),
                                                                                                        fit: BoxFit.cover,
                                                                                                      ),
                                                                                                    ),
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                              Container(
                                                                                                width: width * 0.025,
                                                                                                height: width * 0.025,
                                                                                                decoration: BoxDecoration(
                                                                                                  borderRadius: BorderRadius.circular(5),
                                                                                                  color: Colors.white,
                                                                                                ),
                                                                                                child: Padding(
                                                                                                  padding: EdgeInsets.all(
                                                                                                    width * 0.0,
                                                                                                  ),
                                                                                                  child: Container(
                                                                                                    width: width * 0.034,
                                                                                                    height: width * 0.042,
                                                                                                    decoration: BoxDecoration(
                                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                                      image: DecorationImage(
                                                                                                        image: NetworkImage(
                                                                                                          "${Variables.ipv4_local}/storage/${url_image[4].toString()}",
                                                                                                          scale: 1,
                                                                                                        ),
                                                                                                        fit: BoxFit.cover,
                                                                                                      ),
                                                                                                    ),
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            ],
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              )
                                                                            : Container(),
                                          ]
                                        : [
                                            // ...
                                            // tipe collage b atau strip b
                                            // ...
                                            choose_layout == "layout 1" &&
                                                    url_image_b1.isNotEmpty
                                                ?

                                                // Layout 1 B1, Kecil Atas
                                                Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            12.0),
                                                    child: InkWell(
                                                      onTap: () async {
                                                        // ---
                                                        setState(() {
                                                          pilih_kanvas =
                                                              "kanvas 1";
                                                        });
                                                      },
                                                      child: Container(
                                                        width: width * 0.0925,
                                                        height: height * 0.23,
                                                        decoration:
                                                            pilih_background1 !=
                                                                    ""
                                                                ? BoxDecoration(
                                                                    image:
                                                                        DecorationImage(
                                                                      // last visit code here
                                                                      image: NetworkImage(
                                                                          "${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                      fit: BoxFit
                                                                          .cover,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(5),
                                                                    color: Colors
                                                                        .white,
                                                                  )
                                                                : BoxDecoration(
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(5),
                                                                    color: Colors
                                                                        .black
                                                                        .withOpacity(
                                                                            0.7),
                                                                  ),
                                                        child: Column(
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.01,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.0725,
                                                                height: width *
                                                                    0.0725,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              5),
                                                                  color: Colors
                                                                      .white,
                                                                  image:
                                                                      DecorationImage(
                                                                    image:
                                                                        NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}",
                                                                      scale: 1,
                                                                    ),
                                                                    fit: BoxFit
                                                                        .contain,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                :

                                                // Layout 2 B1, Kecil Atas
                                                choose_layout == "layout 2" &&
                                                        url_image_b1.isNotEmpty
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(12.0),
                                                        child: InkWell(
                                                          onTap: () async {
                                                            // ---
                                                            setState(() {
                                                              pilih_kanvas =
                                                                  "kanvas 1";
                                                            });
                                                          },
                                                          child: Container(
                                                            width:
                                                                width * 0.0925,
                                                            height:
                                                                height * 0.23,
                                                            decoration:
                                                                choose_background !=
                                                                        ""
                                                                    ? BoxDecoration(
                                                                        image:
                                                                            DecorationImage(
                                                                          // last visit code here
                                                                          image:
                                                                              NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                          fit: BoxFit
                                                                              .cover,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .white,
                                                                      )
                                                                    : BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .black
                                                                            .withOpacity(0.7),
                                                                      ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0,
                                                              ),
                                                              child:
                                                                  // .................................
                                                                  // layout row drag target main view
                                                                  // .................................
                                                                  Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                children: [
                                                                  // .............................
                                                                  // layout drag target main view
                                                                  // .............................

                                                                  // ============
                                                                  // kolom card 0
                                                                  Container(
                                                                    width: width *
                                                                        0.035,
                                                                    height:
                                                                        width *
                                                                            0.035,
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0,
                                                                      ),
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.035,
                                                                        height: width *
                                                                            0.035,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(10),
                                                                          image:
                                                                              DecorationImage(
                                                                            image:
                                                                                NetworkImage(
                                                                              "${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}",
                                                                              scale: 1,
                                                                            ),
                                                                            fit:
                                                                                BoxFit.cover,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      // ),
                                                                    ),
                                                                  ),

                                                                  // ============
                                                                  // kolom card 1
                                                                  Container(
                                                                    width: width *
                                                                        0.035,
                                                                    height:
                                                                        width *
                                                                            0.035,
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0,
                                                                      ),
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.035,
                                                                        height: width *
                                                                            0.035,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(10),
                                                                          image:
                                                                              DecorationImage(
                                                                            image:
                                                                                NetworkImage(
                                                                              "${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}",
                                                                              scale: 1,
                                                                            ),
                                                                            fit:
                                                                                BoxFit.cover,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      // ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    :

                                                    // Layout 3 B1, Kecil Atas
                                                    choose_layout ==
                                                                "layout 3" &&
                                                            url_image_b1
                                                                .isNotEmpty
                                                        ? Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(12.0),
                                                            child: InkWell(
                                                              onTap: () async {
                                                                // ---
                                                                setState(() {
                                                                  pilih_kanvas =
                                                                      "kanvas 1";
                                                                });
                                                              },
                                                              child: Container(
                                                                width: width *
                                                                    0.092,
                                                                height: height *
                                                                    0.23,
                                                                decoration:
                                                                    choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                child: Padding(
                                                                  padding:
                                                                      EdgeInsets
                                                                          .all(
                                                                    width * 0.0,
                                                                  ),
                                                                  child: Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceEvenly,
                                                                        children: [
                                                                          // ---
                                                                          Container(
                                                                            width:
                                                                                width * 0.042,
                                                                            height:
                                                                                width * 0.042,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.042,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            width:
                                                                                width * 0.042,
                                                                            height:
                                                                                width * 0.042,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.042,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          )
                                                        :

                                                        // Layout 4 B1, Kecil Atas
                                                        choose_layout ==
                                                                    "layout 4" &&
                                                                url_image_b1
                                                                    .isNotEmpty
                                                            ? Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        12.0),
                                                                child: InkWell(
                                                                  onTap:
                                                                      () async {
                                                                    setState(
                                                                        () {
                                                                      pilih_kanvas =
                                                                          "kanvas 1";
                                                                    });
                                                                    // ---
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    width: width *
                                                                        0.092,
                                                                    height:
                                                                        height *
                                                                            0.24,
                                                                    decoration: choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(15),
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0025,
                                                                      ),
                                                                      child:
                                                                          Row(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceEvenly,
                                                                        children: [
                                                                          // .............................
                                                                          // layout drag target main view
                                                                          // .............................

                                                                          // ============
                                                                          // kolom card 0
                                                                          Container(
                                                                            width:
                                                                                width * 0.025,
                                                                            height:
                                                                                width * 0.025,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.034,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),

                                                                          // ============
                                                                          // kolom card 1
                                                                          Container(
                                                                            width:
                                                                                width * 0.025,
                                                                            height:
                                                                                width * 0.025,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.034,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),

                                                                          Container(
                                                                            width:
                                                                                width * 0.025,
                                                                            height:
                                                                                width * 0.025,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.034,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image_b1[2].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              )
                                                            :

                                                            // Layout 5 B1, Kecil Atas
                                                            choose_layout ==
                                                                        "layout 5" &&
                                                                    url_image_b1
                                                                        .isNotEmpty
                                                                ? Padding(
                                                                    padding:
                                                                        const EdgeInsets
                                                                            .all(
                                                                            12.0),
                                                                    child:
                                                                        InkWell(
                                                                      onTap:
                                                                          () async {
                                                                        setState(
                                                                            () {
                                                                          pilih_kanvas =
                                                                              "kanvas 1";
                                                                        });
                                                                        // ---
                                                                      },
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: height *
                                                                            0.23,
                                                                        decoration: choose_background !=
                                                                                ""
                                                                            ? BoxDecoration(
                                                                                image: DecorationImage(
                                                                                  // last visit code here
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                                borderRadius: BorderRadius.circular(5),
                                                                                color: Colors.white,
                                                                              )
                                                                            : BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(5),
                                                                                color: Colors.black.withOpacity(0.7),
                                                                              ),
                                                                        child:
                                                                            Padding(
                                                                          padding:
                                                                              EdgeInsets.all(
                                                                            width *
                                                                                0.0,
                                                                          ),
                                                                          child:
                                                                              Column(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.spaceEvenly,
                                                                            children: [
                                                                              // .............................
                                                                              // layout drag target main view
                                                                              // .............................

                                                                              // ============
                                                                              // kolom card 0
                                                                              Container(
                                                                                width: width * 0.035,
                                                                                height: width * 0.035,
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(
                                                                                    width * 0.0,
                                                                                  ),
                                                                                  child: Container(
                                                                                    width: width * 0.035,
                                                                                    height: width * 0.035,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      image: DecorationImage(
                                                                                        image: NetworkImage(
                                                                                          "${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}",
                                                                                          scale: 1,
                                                                                        ),
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  // ),
                                                                                ),
                                                                              ),

                                                                              // ============
                                                                              // kolom card 1
                                                                              Container(
                                                                                width: width * 0.035,
                                                                                height: width * 0.035,
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(
                                                                                    width * 0.0,
                                                                                  ),
                                                                                  child: Container(
                                                                                    width: width * 0.035,
                                                                                    height: width * 0.035,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      image: DecorationImage(
                                                                                        image: NetworkImage(
                                                                                          "${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}",
                                                                                          scale: 1,
                                                                                        ),
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  // ),
                                                                                ),
                                                                              ),

                                                                              // ============
                                                                              // kolom card 2
                                                                              Container(
                                                                                width: width * 0.035,
                                                                                height: width * 0.035,
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(
                                                                                    width * 0.0,
                                                                                  ),
                                                                                  child: Container(
                                                                                    width: width * 0.035,
                                                                                    height: width * 0.035,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      image: DecorationImage(
                                                                                        image: NetworkImage(
                                                                                          "${Variables.ipv4_local}/storage/${url_image_b1[2].toString()}",
                                                                                          scale: 1,
                                                                                        ),
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  )
                                                                :

                                                                // Layout 6 B1, Kecil Atas
                                                                choose_layout ==
                                                                            "layout 6" &&
                                                                        url_image_b1
                                                                            .isNotEmpty
                                                                    ? Padding(
                                                                        padding: const EdgeInsets
                                                                            .all(
                                                                            12.0),
                                                                        child:
                                                                            InkWell(
                                                                          onTap:
                                                                              () async {
                                                                            // ---
                                                                            setState(() {
                                                                              pilih_kanvas = "kanvas 1";
                                                                            });
                                                                          },
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.0925,
                                                                            height:
                                                                                height * 0.23,
                                                                            decoration: choose_background != ""
                                                                                ? BoxDecoration(
                                                                                    image: DecorationImage(
                                                                                      // last visit code here
                                                                                      image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                                      fit: BoxFit.cover,
                                                                                    ),
                                                                                    borderRadius: BorderRadius.circular(5),
                                                                                    color: Colors.white,
                                                                                  )
                                                                                : BoxDecoration(
                                                                                    borderRadius: BorderRadius.circular(5),
                                                                                    color: Colors.black.withOpacity(0.7),
                                                                                  ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0025,
                                                                              ),
                                                                              child: Row(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .................................
                                                                                  // layout row drag target main view
                                                                                  // .................................
                                                                                  Column(
                                                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                    children: [
                                                                                      // .............................
                                                                                      // layout drag target main view
                                                                                      // .............................

                                                                                      // ============
                                                                                      // kolom card 0
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          // ),
                                                                                        ),
                                                                                      ),

                                                                                      // ============
                                                                                      // kolom card 1
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),

                                                                                  Column(
                                                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                    children: [
                                                                                      // .............................
                                                                                      // layout drag target main view
                                                                                      // .............................

                                                                                      // ============
                                                                                      // kolom card 2
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image_b1[2].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          // ),
                                                                                        ),
                                                                                      ),

                                                                                      // ============
                                                                                      // kolom card 3
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image_b1[3].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          // ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      )
                                                                    : Container(),
                                            choose_layout2 == "layout 1" &&
                                                    url_image_b2.isNotEmpty
                                                ?

                                                // Layout 1 B1, Kecil Atas
                                                Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            12.0),
                                                    child: InkWell(
                                                      onTap: () async {
                                                        // ---
                                                        setState(() {
                                                          pilih_kanvas =
                                                              "kanvas 2";
                                                        });
                                                      },
                                                      child: Container(
                                                        width: width * 0.0925,
                                                        height: height * 0.23,
                                                        decoration:
                                                            pilih_background1 !=
                                                                    ""
                                                                ? BoxDecoration(
                                                                    image:
                                                                        DecorationImage(
                                                                      // last visit code here
                                                                      image: NetworkImage(
                                                                          "${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                      fit: BoxFit
                                                                          .cover,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(5),
                                                                    color: Colors
                                                                        .white,
                                                                  )
                                                                : BoxDecoration(
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(5),
                                                                    color: Colors
                                                                        .black
                                                                        .withOpacity(
                                                                            0.7),
                                                                  ),
                                                        child: Column(
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.01,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.0725,
                                                                height: width *
                                                                    0.0725,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              5),
                                                                  color: Colors
                                                                      .white,
                                                                  image:
                                                                      DecorationImage(
                                                                    image:
                                                                        NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}",
                                                                      scale: 1,
                                                                    ),
                                                                    fit: BoxFit
                                                                        .contain,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                :

                                                // Layout 2 B1, Kecil Atas
                                                choose_layout2 == "layout 2" &&
                                                        url_image_b2.isNotEmpty
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(12.0),
                                                        child: InkWell(
                                                          onTap: () async {
                                                            // ---
                                                            setState(() {
                                                              pilih_kanvas =
                                                                  "kanvas 2";
                                                            });
                                                          },
                                                          child: Container(
                                                            width:
                                                                width * 0.0925,
                                                            height:
                                                                height * 0.23,
                                                            decoration:
                                                                choose_background !=
                                                                        ""
                                                                    ? BoxDecoration(
                                                                        image:
                                                                            DecorationImage(
                                                                          // last visit code here
                                                                          image:
                                                                              NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                          fit: BoxFit
                                                                              .cover,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .white,
                                                                      )
                                                                    : BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .black
                                                                            .withOpacity(0.7),
                                                                      ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0,
                                                              ),
                                                              child:
                                                                  // .................................
                                                                  // layout row drag target main view
                                                                  // .................................
                                                                  Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                children: [
                                                                  // .............................
                                                                  // layout drag target main view
                                                                  // .............................

                                                                  // ============
                                                                  // kolom card 0
                                                                  Container(
                                                                    width: width *
                                                                        0.035,
                                                                    height:
                                                                        width *
                                                                            0.035,
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0,
                                                                      ),
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.035,
                                                                        height: width *
                                                                            0.035,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(10),
                                                                          image:
                                                                              DecorationImage(
                                                                            image:
                                                                                NetworkImage(
                                                                              "${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}",
                                                                              scale: 1,
                                                                            ),
                                                                            fit:
                                                                                BoxFit.cover,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      // ),
                                                                    ),
                                                                  ),

                                                                  // ============
                                                                  // kolom card 1
                                                                  Container(
                                                                    width: width *
                                                                        0.035,
                                                                    height:
                                                                        width *
                                                                            0.035,
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0,
                                                                      ),
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.035,
                                                                        height: width *
                                                                            0.035,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(10),
                                                                          image:
                                                                              DecorationImage(
                                                                            image:
                                                                                NetworkImage(
                                                                              "${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}",
                                                                              scale: 1,
                                                                            ),
                                                                            fit:
                                                                                BoxFit.cover,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      // ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    :

                                                    // Layout 3 B1, Kecil Atas
                                                    choose_layout2 ==
                                                                "layout 3" &&
                                                            url_image_b2
                                                                .isNotEmpty
                                                        ? Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(12.0),
                                                            child: InkWell(
                                                              onTap: () async {
                                                                // ---
                                                                setState(() {
                                                                  pilih_kanvas =
                                                                      "kanvas 2";
                                                                });
                                                              },
                                                              child: Container(
                                                                width: width *
                                                                    0.092,
                                                                height: height *
                                                                    0.23,
                                                                decoration:
                                                                    choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                child: Padding(
                                                                  padding:
                                                                      EdgeInsets
                                                                          .all(
                                                                    width * 0.0,
                                                                  ),
                                                                  child: Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceEvenly,
                                                                        children: [
                                                                          // ---
                                                                          Container(
                                                                            width:
                                                                                width * 0.042,
                                                                            height:
                                                                                width * 0.042,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.042,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            width:
                                                                                width * 0.042,
                                                                            height:
                                                                                width * 0.042,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.042,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          )
                                                        :

                                                        // Layout 4 B1, Kecil Atas
                                                        choose_layout2 ==
                                                                    "layout 4" &&
                                                                url_image_b2
                                                                    .isNotEmpty
                                                            ? Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        12.0),
                                                                child: InkWell(
                                                                  onTap:
                                                                      () async {
                                                                    setState(
                                                                        () {
                                                                      pilih_kanvas =
                                                                          "kanvas 2";
                                                                    });
                                                                    // ---
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    width: width *
                                                                        0.092,
                                                                    height:
                                                                        height *
                                                                            0.24,
                                                                    decoration: choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(15),
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0025,
                                                                      ),
                                                                      child:
                                                                          Row(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceEvenly,
                                                                        children: [
                                                                          // .............................
                                                                          // layout drag target main view
                                                                          // .............................

                                                                          // ============
                                                                          // kolom card 0
                                                                          Container(
                                                                            width:
                                                                                width * 0.025,
                                                                            height:
                                                                                width * 0.025,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.034,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),

                                                                          // ============
                                                                          // kolom card 1
                                                                          Container(
                                                                            width:
                                                                                width * 0.025,
                                                                            height:
                                                                                width * 0.025,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.034,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),

                                                                          Container(
                                                                            width:
                                                                                width * 0.025,
                                                                            height:
                                                                                width * 0.025,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(5),
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0,
                                                                              ),
                                                                              child: Container(
                                                                                width: width * 0.034,
                                                                                height: width * 0.042,
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  image: DecorationImage(
                                                                                    image: NetworkImage(
                                                                                      "${Variables.ipv4_local}/storage/${url_image_b2[2].toString()}",
                                                                                      scale: 1,
                                                                                    ),
                                                                                    fit: BoxFit.cover,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              )
                                                            :

                                                            // Layout 5 B1, Kecil Atas
                                                            choose_layout2 ==
                                                                        "layout 5" &&
                                                                    url_image_b2
                                                                        .isNotEmpty
                                                                ? Padding(
                                                                    padding:
                                                                        const EdgeInsets
                                                                            .all(
                                                                            12.0),
                                                                    child:
                                                                        InkWell(
                                                                      onTap:
                                                                          () async {
                                                                        setState(
                                                                            () {
                                                                          pilih_kanvas =
                                                                              "kanvas 2";
                                                                        });
                                                                        // ---
                                                                      },
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: height *
                                                                            0.23,
                                                                        decoration: choose_background !=
                                                                                ""
                                                                            ? BoxDecoration(
                                                                                image: DecorationImage(
                                                                                  // last visit code here
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                                borderRadius: BorderRadius.circular(5),
                                                                                color: Colors.white,
                                                                              )
                                                                            : BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(5),
                                                                                color: Colors.black.withOpacity(0.7),
                                                                              ),
                                                                        child:
                                                                            Padding(
                                                                          padding:
                                                                              EdgeInsets.all(
                                                                            width *
                                                                                0.0,
                                                                          ),
                                                                          child:
                                                                              Column(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.spaceEvenly,
                                                                            children: [
                                                                              // .............................
                                                                              // layout drag target main view
                                                                              // .............................

                                                                              // ============
                                                                              // kolom card 0
                                                                              Container(
                                                                                width: width * 0.035,
                                                                                height: width * 0.035,
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(
                                                                                    width * 0.0,
                                                                                  ),
                                                                                  child: Container(
                                                                                    width: width * 0.035,
                                                                                    height: width * 0.035,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      image: DecorationImage(
                                                                                        image: NetworkImage(
                                                                                          "${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}",
                                                                                          scale: 1,
                                                                                        ),
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  // ),
                                                                                ),
                                                                              ),

                                                                              // ============
                                                                              // kolom card 1
                                                                              Container(
                                                                                width: width * 0.035,
                                                                                height: width * 0.035,
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(
                                                                                    width * 0.0,
                                                                                  ),
                                                                                  child: Container(
                                                                                    width: width * 0.035,
                                                                                    height: width * 0.035,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      image: DecorationImage(
                                                                                        image: NetworkImage(
                                                                                          "${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}",
                                                                                          scale: 1,
                                                                                        ),
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  // ),
                                                                                ),
                                                                              ),

                                                                              // ============
                                                                              // kolom card 2
                                                                              Container(
                                                                                width: width * 0.035,
                                                                                height: width * 0.035,
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(
                                                                                    width * 0.0,
                                                                                  ),
                                                                                  child: Container(
                                                                                    width: width * 0.035,
                                                                                    height: width * 0.035,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(10),
                                                                                      image: DecorationImage(
                                                                                        image: NetworkImage(
                                                                                          "${Variables.ipv4_local}/storage/${url_image_b2[2].toString()}",
                                                                                          scale: 1,
                                                                                        ),
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  )
                                                                :

                                                                // Layout 6 B1, Kecil Atas
                                                                choose_layout2 ==
                                                                            "layout 6" &&
                                                                        url_image_b2
                                                                            .isNotEmpty
                                                                    ? Padding(
                                                                        padding: const EdgeInsets
                                                                            .all(
                                                                            12.0),
                                                                        child:
                                                                            InkWell(
                                                                          onTap:
                                                                              () async {
                                                                            // ---
                                                                            setState(() {
                                                                              pilih_kanvas = "kanvas 2";
                                                                            });
                                                                          },
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.0925,
                                                                            height:
                                                                                height * 0.23,
                                                                            decoration: choose_background != ""
                                                                                ? BoxDecoration(
                                                                                    image: DecorationImage(
                                                                                      // last visit code here
                                                                                      image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                                      fit: BoxFit.cover,
                                                                                    ),
                                                                                    borderRadius: BorderRadius.circular(5),
                                                                                    color: Colors.white,
                                                                                  )
                                                                                : BoxDecoration(
                                                                                    borderRadius: BorderRadius.circular(5),
                                                                                    color: Colors.black.withOpacity(0.7),
                                                                                  ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsets.all(
                                                                                width * 0.0025,
                                                                              ),
                                                                              child: Row(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .................................
                                                                                  // layout row drag target main view
                                                                                  // .................................
                                                                                  Column(
                                                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                    children: [
                                                                                      // .............................
                                                                                      // layout drag target main view
                                                                                      // .............................

                                                                                      // ============
                                                                                      // kolom card 0
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          // ),
                                                                                        ),
                                                                                      ),

                                                                                      // ============
                                                                                      // kolom card 1
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),

                                                                                  Column(
                                                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                    children: [
                                                                                      // .............................
                                                                                      // layout drag target main view
                                                                                      // .............................

                                                                                      // ============
                                                                                      // kolom card 2
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image_b2[2].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          // ),
                                                                                        ),
                                                                                      ),

                                                                                      // ============
                                                                                      // kolom card 3
                                                                                      Container(
                                                                                        width: width * 0.017,
                                                                                        height: width * 0.017,
                                                                                        decoration: choose_background != ""
                                                                                            ? BoxDecoration(
                                                                                                borderRadius: BorderRadius.circular(5),
                                                                                                color: Colors.white,
                                                                                              )
                                                                                            : null,
                                                                                        child: Padding(
                                                                                          padding: EdgeInsets.all(
                                                                                            width * 0.0,
                                                                                          ),
                                                                                          child: Container(
                                                                                            width: width * 0.017,
                                                                                            height: width * 0.017,
                                                                                            decoration: BoxDecoration(
                                                                                              borderRadius: BorderRadius.circular(10),
                                                                                              image: DecorationImage(
                                                                                                image: NetworkImage(
                                                                                                  "${Variables.ipv4_local}/storage/${url_image_b2[3].toString()}",
                                                                                                  scale: 1,
                                                                                                ),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          // ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      )
                                                                    : Container(),
                                          ],
                              ),
                              // ============ end pilih kanvas atas tengah kecil =================
                              // =================================================================
                            ),
                          ),
                        ),

                        Spacer(),

                        Padding(
                          padding: EdgeInsets.only(bottom: width * 0.055),
                          child: OutlinedButton(
                            style: TextButton.styleFrom(
                              textStyle: Theme.of(context).textTheme.labelLarge,
                              backgroundColor: Colors.black.withOpacity(0.7),
                            ),
                            onPressed: () {
                              // do onpressed...
                              Navigator.push(
                                context,
                                PageTransition(
                                    type: PageTransitionType.fade,
                                    child: LayoutWidget(
                                      nama: nama,
                                      title: title,
                                      nama_filter: this.nama,
                                      backgrounds: backgrounds,
                                    ),
                                    inheritTheme: true,
                                    ctx: context),
                              );
                            },
                            child: Container(
                              // color: Colors.transparent,
                              width: width * 0.17,
                              // height: height * 0.012,
                              child: Padding(
                                padding: const EdgeInsets.only(
                                  top: 8,
                                  bottom: 8,
                                ),
                                child: Stack(
                                  children: <Widget>[
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: FaIcon(
                                        FontAwesomeIcons.caretLeft,
                                        color: Colors.white,
                                        size: width * 0.015,
                                      ),
                                    ),
                                    Align(
                                        alignment: Alignment.center,
                                        child: Text(
                                          "Kembali".toUpperCase(),
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontSize: width * 0.010,
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ))
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // ........................................
                  // End - Component Kiri Layout Pilih Kanvas
                  // ........................................

                  Container(
                    width: width * 0.5,
                    height: height * 0.8,
                    // color: Colors.transparent,
                    child: Center(
                      child: ScrollConfiguration(
                        behavior: ScrollConfiguration.of(context)
                            .copyWith(scrollbars: false),
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children:
                                (title.toString().contains("Collage A") ||
                                        title.toString().contains("Strip A") ||
                                        title.toString().contains("Paket A"))
                                    ? [
                                        // top view layout choose view

                                        // layout yang dipilih body view / main view
                                        // =========================================
                                        // layout yang dipilih body view / main view
                                        // =========================================

                                        // ===============================
                                        // ======= layout Main View ======
                                        // ===============================

                                        // ..................
                                        // layout main view
                                        // ..................

                                        choose_layout == "layout 1" &&
                                                url_image.isNotEmpty
                                            ? Container(
                                                width: 600,
                                                height: 900,
                                                decoration: choose_background !=
                                                        ""
                                                    ? BoxDecoration(
                                                        image: DecorationImage(
                                                          // last visit code here
                                                          image: NetworkImage(
                                                            "${Variables.ipv4_local}/storage/background/${choose_background.toString()}",
                                                          ),
                                                          fit: BoxFit.cover,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                        color: Colors.white,
                                                      )
                                                    : BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                        color: Colors.black
                                                            .withOpacity(0.7),
                                                      ),
                                                child: Padding(
                                                  padding: EdgeInsets.all(
                                                    width * 0.0025,
                                                  ),
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceEvenly,
                                                    children: [
                                                      // .................................
                                                      // layout row drag target main view
                                                      // .................................
                                                      Container(
                                                        width: 600,
                                                        height: 600,
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(5),
                                                        ),
                                                        child: Padding(
                                                          padding:
                                                              EdgeInsets.all(
                                                            width * 0.0001,
                                                          ),
                                                          child: Container(
                                                            width: width * 0.12,
                                                            height:
                                                                height * 0.12,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          45),
                                                              image:
                                                                  DecorationImage(
                                                                image: NetworkImage(
                                                                    "${Variables.ipv4_local}/storage/${url_image[0].toString()}"),
                                                                fit: BoxFit
                                                                    .cover,
                                                              ),
                                                            ),
                                                          ),
                                                          // ),
                                                        ),
                                                      ),

                                                      SizedBox(height: 12),
                                                      Center(
                                                        child: Container(
                                                          width: width * 0.25,
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        45),
                                                            color: Color
                                                                    .fromARGB(
                                                                        255,
                                                                        80,
                                                                        133,
                                                                        123)
                                                                .withOpacity(
                                                                    0.4),
                                                          ),
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(25.0),
                                                            child: Text(
                                                              string_logo != ""
                                                                  ? string_logo
                                                                      .toString()
                                                                      .toUpperCase()
                                                                  : "Photobooth Text",
                                                              style: TextStyle(
                                                                fontSize: 35,
                                                                color: Colors
                                                                    .white,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w900,
                                                              ),
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                          height:
                                                              height * 0.01),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            :

                                            // ..................
                                            // layout 2 main view
                                            // ..................
                                            choose_layout == "layout 2" &&
                                                    url_image.isNotEmpty
                                                ? Container(
                                                    width: 600,
                                                    height: 900,
                                                    decoration:
                                                        choose_background != ""
                                                            ? BoxDecoration(
                                                                image:
                                                                    DecorationImage(
                                                                  // last visit code here
                                                                  image: NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                                color: Colors
                                                                    .white,
                                                              )
                                                            : BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                        0.7),
                                                              ),
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceEvenly,
                                                      children: [
                                                        // .................................
                                                        // layout row drag target main view
                                                        // .................................
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceEvenly,
                                                          children: [
                                                            // .............................
                                                            // layout drag target main view
                                                            // .............................

                                                            // ============
                                                            // dragtarget 1
                                                            Container(
                                                              width:
                                                                  width * 0.14,
                                                              height:
                                                                  width * 0.14,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: Colors
                                                                    .white
                                                                    .withOpacity(
                                                                        0.3),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                                image:
                                                                    DecorationImage(
                                                                  image:
                                                                      NetworkImage(
                                                                    "${Variables.ipv4_local}/storage/${url_image[0].toString()}",
                                                                    // "${Variables.ipv4_local}/storage/background/1720117923_bg1.jpg",
                                                                    scale: 1,
                                                                  ),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),

                                                            // ============
                                                            // dragtarget 2
                                                            Container(
                                                              width:
                                                                  width * 0.14,
                                                              height:
                                                                  width * 0.14,
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                                color: Colors
                                                                    .white
                                                                    .withOpacity(
                                                                        0.3),
                                                                image:
                                                                    DecorationImage(
                                                                  image: NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/${url_image[1].toString()}"),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),

                                                        SizedBox(height: 12),
                                                        Center(
                                                          child: Container(
                                                            width: width * 0.25,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          45),
                                                              color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          80,
                                                                          133,
                                                                          123)
                                                                  .withOpacity(
                                                                      0.4),
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(
                                                                      25.0),
                                                              child: Text(
                                                                string_logo !=
                                                                        ""
                                                                    ? string_logo
                                                                        .toString()
                                                                        .toUpperCase()
                                                                    : "Photobooth Text",
                                                                style:
                                                                    TextStyle(
                                                                  fontSize: 35,
                                                                  color: Colors
                                                                      .white,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w900,
                                                                ),
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        SizedBox(
                                                            height:
                                                                height * 0.01),
                                                      ],
                                                    ),
                                                  )
                                                :

                                                // ..................
                                                // layout 3 main view
                                                // ..................
                                                choose_layout == "layout 3" &&
                                                        url_image.isNotEmpty
                                                    ? Center(
                                                        child: Container(
                                                          width: 600,
                                                          height: 900,
                                                          decoration:
                                                              choose_background !=
                                                                      ""
                                                                  ? BoxDecoration(
                                                                      image:
                                                                          DecorationImage(
                                                                        // last visit code here
                                                                        image: NetworkImage(
                                                                            "${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                        fit: BoxFit
                                                                            .cover,
                                                                      ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              5),
                                                                      color: Colors
                                                                          .white,
                                                                    )
                                                                  : BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              5),
                                                                      color: Colors
                                                                          .black
                                                                          .withOpacity(
                                                                              0.7),
                                                                    ),
                                                          child: Padding(
                                                            padding:
                                                                EdgeInsets.all(
                                                              width * 0.0025,
                                                            ),
                                                            child: Column(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceEvenly,
                                                              children: [
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceAround,
                                                                  children: [
                                                                    // ---
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                          .all(
                                                                          2.0),
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.18,
                                                                        height: width *
                                                                            0.18,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(12),
                                                                          color:
                                                                              Colors.transparent,
                                                                          image:
                                                                              DecorationImage(
                                                                            image:
                                                                                NetworkImage("${Variables.ipv4_local}/storage/${url_image[0].toString()}"),
                                                                            fit:
                                                                                BoxFit.cover,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                          .all(
                                                                          2.0),
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.18,
                                                                        height: width *
                                                                            0.18,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(12),
                                                                          color:
                                                                              Colors.transparent,
                                                                          image:
                                                                              DecorationImage(
                                                                            image:
                                                                                NetworkImage("${Variables.ipv4_local}/storage/${url_image[1].toString()}"),
                                                                            fit:
                                                                                BoxFit.cover,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                    height: 12),
                                                                Center(
                                                                  child:
                                                                      Container(
                                                                    width:
                                                                        width *
                                                                            0.25,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              45),
                                                                      color: Color.fromARGB(
                                                                              255,
                                                                              80,
                                                                              133,
                                                                              123)
                                                                          .withOpacity(
                                                                              0.4),
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: const EdgeInsets
                                                                          .all(
                                                                          25.0),
                                                                      child:
                                                                          Text(
                                                                        string_logo !=
                                                                                ""
                                                                            ? string_logo.toString().toUpperCase()
                                                                            : "Photobooth Text",
                                                                        style:
                                                                            TextStyle(
                                                                          fontSize:
                                                                              35,
                                                                          color:
                                                                              Colors.white,
                                                                          fontWeight:
                                                                              FontWeight.w900,
                                                                        ),
                                                                        textAlign:
                                                                            TextAlign.center,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                    height:
                                                                        height *
                                                                            0.01),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    :

                                                    // ..................
                                                    // layout 4 main view
                                                    // ..................
                                                    choose_layout ==
                                                                "layout 4" &&
                                                            url_image.isNotEmpty
                                                        ? Container(
                                                            width: 600,
                                                            height: 900,
                                                            decoration:
                                                                choose_background !=
                                                                        ""
                                                                    ? BoxDecoration(
                                                                        image:
                                                                            DecorationImage(
                                                                          // last visit code here
                                                                          image:
                                                                              NetworkImage("${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                          fit: BoxFit
                                                                              .cover,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .white,
                                                                      )
                                                                    : BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0025,
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                children: [
                                                                  // .................................
                                                                  // layout row drag target main view
                                                                  // .................................
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 0
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.0925,
                                                                            height:
                                                                                width * 0.0925,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[0].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ============
                                                                      // kolom card 1
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[1].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 2
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[2].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ============
                                                                      // kolom card 3
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[3].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 4
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[4].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ======================
                                                                      // kolom card 6 main view
                                                                      // ======================
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[5].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 4
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[6].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ======================
                                                                      // kolom card 6 main view
                                                                      // ======================
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[7].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  SizedBox(
                                                                      height:
                                                                          12),
                                                                  Center(
                                                                    child:
                                                                        Container(
                                                                      width: width *
                                                                          0.25,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(15),
                                                                        color: Color.fromARGB(
                                                                                255,
                                                                                80,
                                                                                133,
                                                                                123)
                                                                            .withOpacity(0.4),
                                                                      ),
                                                                      child:
                                                                          Padding(
                                                                        padding: const EdgeInsets
                                                                            .all(
                                                                            25.0),
                                                                        child:
                                                                            Text(
                                                                          string_logo != ""
                                                                              ? string_logo.toString().toUpperCase()
                                                                              : "Photobooth Text",
                                                                          style:
                                                                              TextStyle(
                                                                            fontSize:
                                                                                35,
                                                                            color:
                                                                                Colors.white,
                                                                            fontWeight:
                                                                                FontWeight.w900,
                                                                          ),
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                      height: height *
                                                                          0.01),
                                                                ],
                                                              ),
                                                            ),
                                                          )
                                                        :

                                                        // ..................
                                                        // layout 5 main view
                                                        // ..................
                                                        choose_layout ==
                                                                    "layout 5" &&
                                                                url_image
                                                                    .isNotEmpty
                                                            ? Container(
                                                                width: 600,
                                                                height: 900,
                                                                decoration:
                                                                    choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                child: Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceEvenly,
                                                                  children: [
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceEvenly,
                                                                      children: [
                                                                        // .................................
                                                                        // layout row drag target main view
                                                                        // .................................
                                                                        Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceEvenly,
                                                                          children: [
                                                                            // .............................
                                                                            // layout drag target main view
                                                                            // .............................

                                                                            // ============
                                                                            // dragtarget 1
                                                                            Container(
                                                                              width: width * 0.13,
                                                                              height: width * 0.13,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage(
                                                                                    "${Variables.ipv4_local}/storage/${url_image[0].toString()}",
                                                                                    scale: 1,
                                                                                  ),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),

                                                                            SizedBox(
                                                                              height: height * 0.035,
                                                                            ),
                                                                            // ============
                                                                            // dragtarget 2
                                                                            Container(
                                                                              width: width * 0.13,
                                                                              height: width * 0.13,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[1].toString()}"

                                                                                      // "${Variables.ipv4_local}/storage/background/1720117923_bg1.jpg",
                                                                                      ),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),

                                                                            SizedBox(height: 12),
                                                                          ],
                                                                        ),

                                                                        // row 2
                                                                        Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceEvenly,
                                                                          children: [
                                                                            SizedBox(
                                                                              height: height * 0.15,
                                                                            ),
                                                                            // ...............................
                                                                            // layout drag target main view
                                                                            // .............................
                                                                            Container(
                                                                              width: width * 0.13,
                                                                              height: width * 0.13,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[2].toString()}"),
                                                                                  scale: 1,
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),

                                                                            SizedBox(
                                                                              height: height * 0.035,
                                                                            ),
                                                                            Container(
                                                                              width: width * 0.13,
                                                                              height: width * 0.13,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[3].toString()}"),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    Center(
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.25,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(15),
                                                                          color:
                                                                              Color.fromARGB(255, 80, 133, 123).withOpacity(0.4),
                                                                        ),
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              25.0),
                                                                          child:
                                                                              Text(
                                                                            string_logo != ""
                                                                                ? string_logo.toString().toUpperCase()
                                                                                : "Photobooth Text",
                                                                            style:
                                                                                TextStyle(
                                                                              fontSize: 35,
                                                                              color: Colors.white,
                                                                              fontWeight: FontWeight.w900,
                                                                            ),
                                                                            textAlign:
                                                                                TextAlign.center,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    SizedBox(
                                                                        height: height *
                                                                            0.025),
                                                                  ],
                                                                ),
                                                              )
                                                            : choose_layout ==
                                                                        "layout 6" &&
                                                                    url_image
                                                                        .isNotEmpty
                                                                ? Container(
                                                                    width: 600,
                                                                    height: 900,
                                                                    decoration: choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${choose_background.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0025,
                                                                      ),
                                                                      child:
                                                                          Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceEvenly,
                                                                        children: [
                                                                          Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.spaceEvenly,
                                                                            children: [
                                                                              // .................................
                                                                              // layout row drag target main view
                                                                              // .................................
                                                                              Column(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .............................
                                                                                  // layout drag target main view
                                                                                  // .............................

                                                                                  // ============
                                                                                  // kolom card 0
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[0].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  // ============
                                                                                  // kolom card 1
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[1].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[2].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),

                                                                              Column(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .............................
                                                                                  // layout drag target main view
                                                                                  // .............................

                                                                                  // ============
                                                                                  // kolom card 2
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[3].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  // ============
                                                                                  // kolom card 3
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[4].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[5].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),

                                                                              Column(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .............................
                                                                                  // layout drag target main view
                                                                                  // .............................

                                                                                  // ============
                                                                                  // kolom card 4
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[6].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  // ======================
                                                                                  // kolom card 6 main view
                                                                                  // ======================
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[7].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image[8].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ],
                                                                          ),
                                                                          SizedBox(
                                                                              height: 12),
                                                                          Center(
                                                                            child:
                                                                                Container(
                                                                              width: width * 0.25,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(15),
                                                                                color: Color.fromARGB(255, 80, 133, 123).withOpacity(0.4),
                                                                              ),
                                                                              child: Padding(
                                                                                padding: const EdgeInsets.all(25.0),
                                                                                child: Text(
                                                                                  string_logo != "" ? string_logo.toString().toUpperCase() : "Photobooth Text",
                                                                                  style: TextStyle(
                                                                                    fontSize: 35,
                                                                                    color: Colors.white,
                                                                                    fontWeight: FontWeight.w900,
                                                                                  ),
                                                                                  textAlign: TextAlign.center,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                              height: height * 0.01),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  )
                                                                : Container(),
                                        // ========================
                                        // ===== end layout 1 =====
                                        // ========================
                                        SizedBox(
                                          height: height * 0.045,
                                        ),
                                      ]
                                    : [
                                        // layout yang dipilih body view / main view B
                                        // ===========================================
                                        // layout yang dipilih body view / main view B
                                        // ===========================================

                                        // ========================
                                        // ===== layout 1 =========
                                        // ========================

                                        // ..................
                                        // layout 1 main view
                                        // ..................

                                        choose_layout == "layout 1" &&
                                                url_image_b1.isNotEmpty
                                            ? Container(
                                                width: 600,
                                                height: 900,
                                                decoration: choose_background !=
                                                        ""
                                                    ? BoxDecoration(
                                                        image: DecorationImage(
                                                          // last visit code here
                                                          image: NetworkImage(
                                                              "${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                          fit: BoxFit.cover,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                        color: Colors.white,
                                                      )
                                                    : BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                        color: Colors.black
                                                            .withOpacity(0.7),
                                                      ),
                                                child: Padding(
                                                  padding: EdgeInsets.all(
                                                    width * 0.0025,
                                                  ),
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceEvenly,
                                                    children: [
                                                      // .................................
                                                      // layout row drag target main view
                                                      // .................................
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: [
                                                          // .............................
                                                          // layout drag target main view
                                                          // .............................

                                                          // ============
                                                          // kolom card 0
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),

                                                          // ============
                                                          // kolom card 1
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),

                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: [
                                                          // .............................
                                                          // layout drag target main view
                                                          // .............................

                                                          // ============
                                                          // kolom card 2
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b1[2].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),

                                                          // ============
                                                          // kolom card 3
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b1[3].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: [
                                                          // .............................
                                                          // layout drag target main view
                                                          // .............................

                                                          // ============
                                                          // kolom card 4
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b1[4].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),

                                                          // ======================
                                                          // kolom card 6 main view
                                                          // ======================
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b1[5].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      SizedBox(height: 12),
                                                      Center(
                                                        child: Container(
                                                          width: width * 0.25,
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        15),
                                                            color: Color
                                                                    .fromARGB(
                                                                        255,
                                                                        80,
                                                                        133,
                                                                        123)
                                                                .withOpacity(
                                                                    0.4),
                                                          ),
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(25.0),
                                                            child: Text(
                                                              string_logo != ""
                                                                  ? string_logo
                                                                      .toString()
                                                                      .toUpperCase()
                                                                  : "Photobooth Text",
                                                              style: TextStyle(
                                                                fontSize: 35,
                                                                color: Colors
                                                                    .white,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w900,
                                                              ),
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                          height:
                                                              height * 0.01),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            :

                                            // ..................
                                            // layout 2 main view
                                            // ..................
                                            choose_layout == "layout 2" &&
                                                    url_image_b1.isNotEmpty
                                                ? Container(
                                                    width: 600,
                                                    height: 900,
                                                    decoration:
                                                        choose_background != ""
                                                            ? BoxDecoration(
                                                                image:
                                                                    DecorationImage(
                                                                  // last visit code here
                                                                  image: NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                                color: Colors
                                                                    .white,
                                                              )
                                                            : BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                        0.7),
                                                              ),
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceEvenly,
                                                      children: [
                                                        // .................................
                                                        // layout row drag target main view
                                                        // .................................
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceEvenly,
                                                          children: [
                                                            // .............................
                                                            // layout drag target main view
                                                            // .............................

                                                            // ============
                                                            // dragtarget 1
                                                            Container(
                                                              width:
                                                                  width * 0.11,
                                                              height:
                                                                  width * 0.11,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: Colors
                                                                    .transparent,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                                image:
                                                                    DecorationImage(
                                                                  image:
                                                                      NetworkImage(
                                                                    "${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}",
                                                                    scale: 1,
                                                                  ),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),

                                                            // ============
                                                            // dragtarget 2
                                                            Container(
                                                              width:
                                                                  width * 0.11,
                                                              height:
                                                                  width * 0.11,
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                                color: Colors
                                                                    .transparent,
                                                                image:
                                                                    DecorationImage(
                                                                  image: NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}"),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),

                                                        // row 2
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceEvenly,
                                                          children: [
                                                            // ...............................
                                                            // layout drag target main view
                                                            // .............................
                                                            Container(
                                                              width:
                                                                  width * 0.11,
                                                              height:
                                                                  width * 0.11,
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                                color: Colors
                                                                    .transparent,
                                                                image:
                                                                    DecorationImage(
                                                                  image: NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/${url_image_b1[2].toString()}"),
                                                                  scale: 1,
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),

                                                            Container(
                                                              width:
                                                                  width * 0.11,
                                                              height:
                                                                  width * 0.11,
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                                color: Colors
                                                                    .transparent,
                                                                image:
                                                                    DecorationImage(
                                                                  image: NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/${url_image_b1[3].toString()}"),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        SizedBox(height: 12),
                                                        Center(
                                                          child: Container(
                                                            width: width * 0.25,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          15),
                                                              color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          80,
                                                                          133,
                                                                          123)
                                                                  .withOpacity(
                                                                      0.4),
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(
                                                                      25.0),
                                                              child: Text(
                                                                string_logo !=
                                                                        ""
                                                                    ? string_logo
                                                                        .toString()
                                                                        .toUpperCase()
                                                                    : "Photobooth Text",
                                                                style:
                                                                    TextStyle(
                                                                  fontSize: 35,
                                                                  color: Colors
                                                                      .white,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w900,
                                                                ),
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        SizedBox(
                                                            height:
                                                                height * 0.01),
                                                      ],
                                                    ),
                                                  )
                                                :

                                                // ..................
                                                // layout 3 main view
                                                // ..................
                                                choose_layout == "layout 3" &&
                                                        url_image_b1.isNotEmpty
                                                    ? Center(
                                                        child: Container(
                                                          width: 600,
                                                          height: 900,
                                                          decoration:
                                                              choose_background !=
                                                                      ""
                                                                  ? BoxDecoration(
                                                                      image:
                                                                          DecorationImage(
                                                                        // last visit code here
                                                                        image: NetworkImage(
                                                                            "${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                        fit: BoxFit
                                                                            .cover,
                                                                      ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              5),
                                                                      color: Colors
                                                                          .white,
                                                                    )
                                                                  : BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              5),
                                                                      color: Colors
                                                                          .white,
                                                                    ),
                                                          child: Padding(
                                                            padding:
                                                                EdgeInsets.all(
                                                              width * 0.0025,
                                                            ),
                                                            child: Column(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceAround,
                                                              children: [
                                                                Row(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceAround,
                                                                  children: [
                                                                    Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceAround,
                                                                      children: [
                                                                        // ---
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              2.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.12,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              color: Colors.transparent,
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),

                                                                        SizedBox(
                                                                            height:
                                                                                height * 0.1),

                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              2.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.12,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              color: Colors.transparent,
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceAround,
                                                                      children: [
                                                                        // ---

                                                                        // ...
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.10,
                                                                            height:
                                                                                width * 0.10,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              color: Colors.transparent,
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[2].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),

                                                                        SizedBox(
                                                                            height:
                                                                                height * 0.045),
                                                                        // ...
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.10,
                                                                            height:
                                                                                width * 0.10,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              color: Colors.transparent,
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[3].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),

                                                                        SizedBox(
                                                                            height:
                                                                                height * 0.045),

                                                                        // ...
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.10,
                                                                            height:
                                                                                width * 0.10,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              color: Colors.transparent,
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[4].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                    height: 12),
                                                                Center(
                                                                  child:
                                                                      Container(
                                                                    width:
                                                                        width *
                                                                            0.25,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              15),
                                                                      color: Color.fromARGB(
                                                                              255,
                                                                              80,
                                                                              133,
                                                                              123)
                                                                          .withOpacity(
                                                                              0.4),
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: const EdgeInsets
                                                                          .all(
                                                                          25.0),
                                                                      child:
                                                                          Text(
                                                                        string_logo !=
                                                                                ""
                                                                            ? string_logo.toString().toUpperCase()
                                                                            : "Photobooth Text",
                                                                        style:
                                                                            TextStyle(
                                                                          fontSize:
                                                                              35,
                                                                          color:
                                                                              Colors.white,
                                                                          fontWeight:
                                                                              FontWeight.w900,
                                                                        ),
                                                                        textAlign:
                                                                            TextAlign.center,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                    height:
                                                                        height *
                                                                            0.01),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    :

                                                    // ..................
                                                    // layout 4 main view
                                                    // ..................
                                                    choose_layout ==
                                                                "layout 4" &&
                                                            url_image_b1
                                                                .isNotEmpty
                                                        ? Container(
                                                            width: 600,
                                                            height: 900,
                                                            decoration:
                                                                choose_background !=
                                                                        ""
                                                                    ? BoxDecoration(
                                                                        image:
                                                                            DecorationImage(
                                                                          // last visit code here
                                                                          image:
                                                                              NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                          fit: BoxFit
                                                                              .cover,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .white,
                                                                      )
                                                                    : BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .black
                                                                            .withOpacity(0.7),
                                                                      ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0025,
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                children: [
                                                                  // .................................
                                                                  // layout row drag target main view
                                                                  // .................................
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 0
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.0925,
                                                                            height:
                                                                                width * 0.0925,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ============
                                                                      // kolom card 1
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 2
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[2].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ============
                                                                      // kolom card 3
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[3].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 4
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[4].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ======================
                                                                      // kolom card 6 main view
                                                                      // ======================
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[5].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 4
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[6].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ======================
                                                                      // kolom card 6 main view
                                                                      // ======================
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[7].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  SizedBox(
                                                                      height:
                                                                          12),
                                                                  Center(
                                                                    child:
                                                                        Container(
                                                                      width: width *
                                                                          0.25,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(15),
                                                                        color: Color.fromARGB(
                                                                                255,
                                                                                80,
                                                                                133,
                                                                                123)
                                                                            .withOpacity(0.4),
                                                                      ),
                                                                      child:
                                                                          Padding(
                                                                        padding: const EdgeInsets
                                                                            .all(
                                                                            25.0),
                                                                        child:
                                                                            Text(
                                                                          string_logo != ""
                                                                              ? string_logo.toString().toUpperCase()
                                                                              : "Photobooth Text",
                                                                          style:
                                                                              TextStyle(
                                                                            fontSize:
                                                                                35,
                                                                            color:
                                                                                Colors.white,
                                                                            fontWeight:
                                                                                FontWeight.w900,
                                                                          ),
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                      height: height *
                                                                          0.01),
                                                                ],
                                                              ),
                                                            ),
                                                          )
                                                        :

                                                        // ..................
                                                        // layout 5 main view
                                                        // ..................
                                                        choose_layout ==
                                                                    "layout 5" &&
                                                                url_image_b1
                                                                    .isNotEmpty
                                                            ? Container(
                                                                width: 600,
                                                                height: 900,
                                                                decoration:
                                                                    choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                child: Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceEvenly,
                                                                  children: [
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceEvenly,
                                                                      children: [
                                                                        // .................................
                                                                        // layout row drag target main view
                                                                        // .................................
                                                                        Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceEvenly,
                                                                          children: [
                                                                            // .............................
                                                                            // layout drag target main view
                                                                            // .............................

                                                                            // ============
                                                                            // dragtarget 1
                                                                            Container(
                                                                              width: width * 0.12,
                                                                              height: width * 0.12,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage(
                                                                                    "${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}",
                                                                                    scale: 1,
                                                                                  ),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),

                                                                            // ...
                                                                            SizedBox(height: height * 0.05),
                                                                            // ============
                                                                            // dragtarget 2
                                                                            Container(
                                                                              width: width * 0.12,
                                                                              height: width * 0.12,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}"

                                                                                      // "${Variables.ipv4_local}/storage/background/1720117923_bg1.jpg",
                                                                                      ),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),

                                                                            SizedBox(height: height * 0.1),
                                                                          ],
                                                                        ),

                                                                        // row 2
                                                                        Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceEvenly,
                                                                          children: [
                                                                            SizedBox(height: height * 0.1),
                                                                            // ...............................
                                                                            // layout drag target main view
                                                                            // .............................
                                                                            Container(
                                                                              width: width * 0.12,
                                                                              height: width * 0.12,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[2].toString()}"),
                                                                                  scale: 1,
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),

                                                                            SizedBox(height: height * 0.05),
                                                                            Container(
                                                                              width: width * 0.12,
                                                                              height: width * 0.12,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[3].toString()}"),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    SizedBox(
                                                                        height:
                                                                            12),
                                                                    Center(
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.25,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(15),
                                                                          color:
                                                                              Color.fromARGB(255, 80, 133, 123).withOpacity(0.4),
                                                                        ),
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              25.0),
                                                                          child:
                                                                              Text(
                                                                            string_logo != ""
                                                                                ? string_logo.toString().toUpperCase()
                                                                                : "Photobooth Text",
                                                                            style:
                                                                                TextStyle(
                                                                              fontSize: 35,
                                                                              color: Colors.white,
                                                                              fontWeight: FontWeight.w900,
                                                                            ),
                                                                            textAlign:
                                                                                TextAlign.center,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    SizedBox(
                                                                        height: height *
                                                                            0.01),
                                                                  ],
                                                                ),
                                                              )
                                                            : choose_layout ==
                                                                        "layout 6" &&
                                                                    url_image_b1
                                                                        .isNotEmpty
                                                                ? Container(
                                                                    width: 600,
                                                                    height: 900,
                                                                    decoration: choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background1.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0025,
                                                                      ),
                                                                      child:
                                                                          Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceEvenly,
                                                                        children: [
                                                                          Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.spaceEvenly,
                                                                            children: [
                                                                              // .................................
                                                                              // layout row drag target main view
                                                                              // .................................
                                                                              Column(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .............................
                                                                                  // layout drag target main view
                                                                                  // .............................

                                                                                  // ============
                                                                                  // kolom card 0
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[0].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  // ============
                                                                                  // kolom card 1
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[1].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[2].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),

                                                                              Column(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .............................
                                                                                  // layout drag target main view
                                                                                  // .............................

                                                                                  // ============
                                                                                  // kolom card 2
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[3].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  // ============
                                                                                  // kolom card 3
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[4].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[5].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),

                                                                              Column(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .............................
                                                                                  // layout drag target main view
                                                                                  // .............................

                                                                                  // ============
                                                                                  // kolom card 4
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[6].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  // ======================
                                                                                  // kolom card 6 main view
                                                                                  // ======================
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[7].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b1[8].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ],
                                                                          ),
                                                                          SizedBox(
                                                                              height: 12),
                                                                          Center(
                                                                            child:
                                                                                Container(
                                                                              width: width * 0.25,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(15),
                                                                                color: Color.fromARGB(255, 80, 133, 123).withOpacity(0.4),
                                                                              ),
                                                                              child: Padding(
                                                                                padding: const EdgeInsets.all(25.0),
                                                                                child: Text(
                                                                                  string_logo != "" ? string_logo.toString().toUpperCase() : "Photobooth Text",
                                                                                  style: TextStyle(
                                                                                    fontSize: 35,
                                                                                    color: Colors.white,
                                                                                    fontWeight: FontWeight.w900,
                                                                                  ),
                                                                                  textAlign: TextAlign.center,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                              height: height * 0.01),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  )
                                                                : Container(),
                                        // ==============================
                                        // choose 2 layout b
                                        // ==============================
                                        SizedBox(
                                          height: height * 0.045,
                                        ),
                                        choose_layout2 == "layout 1" &&
                                                url_image_b2.isNotEmpty
                                            ? Container(
                                                width: 600,
                                                height: 900,
                                                decoration: choose_background !=
                                                        ""
                                                    ? BoxDecoration(
                                                        image: DecorationImage(
                                                          // last visit code here
                                                          image: NetworkImage(
                                                              "${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                          fit: BoxFit.cover,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                        color: Colors.white,
                                                      )
                                                    : BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                        color: Colors.black
                                                            .withOpacity(0.7),
                                                      ),
                                                child: Padding(
                                                  padding: EdgeInsets.all(
                                                    width * 0.0025,
                                                  ),
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceEvenly,
                                                    children: [
                                                      // .................................
                                                      // layout row drag target main view
                                                      // .................................
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: [
                                                          // .............................
                                                          // layout drag target main view
                                                          // .............................

                                                          // ============
                                                          // kolom card 0
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),

                                                          // ============
                                                          // kolom card 1
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),

                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: [
                                                          // .............................
                                                          // layout drag target main view
                                                          // .............................

                                                          // ============
                                                          // kolom card 2
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b2[2].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),

                                                          // ============
                                                          // kolom card 3
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b2[3].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: [
                                                          // .............................
                                                          // layout drag target main view
                                                          // .............................

                                                          // ============
                                                          // kolom card 4
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b2[4].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),

                                                          // ======================
                                                          // kolom card 6 main view
                                                          // ======================
                                                          Container(
                                                            width: width * 0.10,
                                                            height:
                                                                width * 0.10,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0001,
                                                              ),
                                                              child: Container(
                                                                width: width *
                                                                    0.12,
                                                                height: height *
                                                                    0.12,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12),
                                                                  image:
                                                                      DecorationImage(
                                                                    image: NetworkImage(
                                                                        "${Variables.ipv4_local}/storage/${url_image_b2[5].toString()}"),
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              // ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      SizedBox(height: 12),
                                                      Center(
                                                        child: Container(
                                                          width: width * 0.25,
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        15),
                                                            color: Color
                                                                    .fromARGB(
                                                                        255,
                                                                        80,
                                                                        133,
                                                                        123)
                                                                .withOpacity(
                                                                    0.4),
                                                          ),
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(25.0),
                                                            child: Text(
                                                              string_logo != ""
                                                                  ? string_logo
                                                                      .toString()
                                                                      .toUpperCase()
                                                                  : "Photobooth Text",
                                                              style: TextStyle(
                                                                fontSize: 35,
                                                                color: Colors
                                                                    .white,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w900,
                                                              ),
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                          height:
                                                              height * 0.01),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            :

                                            // ..................
                                            // layout 2 main view
                                            // ..................
                                            choose_layout2 == "layout 2" &&
                                                    url_image_b2.isNotEmpty
                                                ? Container(
                                                    width: 600,
                                                    height: 900,
                                                    decoration:
                                                        choose_background != ""
                                                            ? BoxDecoration(
                                                                image:
                                                                    DecorationImage(
                                                                  // last visit code here
                                                                  image: NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                                color: Colors
                                                                    .white,
                                                              )
                                                            : BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                        0.7),
                                                              ),
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceEvenly,
                                                      children: [
                                                        // .................................
                                                        // layout row drag target main view
                                                        // .................................
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceEvenly,
                                                          children: [
                                                            // .............................
                                                            // layout drag target main view
                                                            // .............................

                                                            // ============
                                                            // dragtarget 1
                                                            Container(
                                                              width:
                                                                  width * 0.11,
                                                              height:
                                                                  width * 0.11,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: Colors
                                                                    .transparent,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                                image:
                                                                    DecorationImage(
                                                                  image:
                                                                      NetworkImage(
                                                                    "${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}",
                                                                    scale: 1,
                                                                  ),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),

                                                            // ============
                                                            // dragtarget 2
                                                            Container(
                                                              width:
                                                                  width * 0.11,
                                                              height:
                                                                  width * 0.11,
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                                color: Colors
                                                                    .transparent,
                                                                image:
                                                                    DecorationImage(
                                                                  image: NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}"),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),

                                                        // row 2
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceEvenly,
                                                          children: [
                                                            // ...............................
                                                            // layout drag target main view
                                                            // .............................
                                                            Container(
                                                              width:
                                                                  width * 0.11,
                                                              height:
                                                                  width * 0.11,
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                                color: Colors
                                                                    .transparent,
                                                                image:
                                                                    DecorationImage(
                                                                  image: NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/${url_image_b2[2].toString()}"),
                                                                  scale: 1,
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),

                                                            Container(
                                                              width:
                                                                  width * 0.11,
                                                              height:
                                                                  width * 0.11,
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                                color: Colors
                                                                    .transparent,
                                                                image:
                                                                    DecorationImage(
                                                                  image: NetworkImage(
                                                                      "${Variables.ipv4_local}/storage/${url_image_b2[3].toString()}"),
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        SizedBox(height: 12),
                                                        Center(
                                                          child: Container(
                                                            width: width * 0.25,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          15),
                                                              color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          80,
                                                                          133,
                                                                          123)
                                                                  .withOpacity(
                                                                      0.4),
                                                            ),
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(
                                                                      25.0),
                                                              child: Text(
                                                                string_logo !=
                                                                        ""
                                                                    ? string_logo
                                                                        .toString()
                                                                        .toUpperCase()
                                                                    : "Photobooth Text",
                                                                style:
                                                                    TextStyle(
                                                                  fontSize: 35,
                                                                  color: Colors
                                                                      .white,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w900,
                                                                ),
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        SizedBox(
                                                            height:
                                                                height * 0.01),
                                                      ],
                                                    ),
                                                  )
                                                :

                                                // ..................
                                                // layout 3 main view
                                                // ..................
                                                choose_layout2 == "layout 3" &&
                                                        url_image_b2.isNotEmpty
                                                    ? Center(
                                                        child: Container(
                                                          width: 600,
                                                          height: 900,
                                                          decoration:
                                                              choose_background !=
                                                                      ""
                                                                  ? BoxDecoration(
                                                                      image:
                                                                          DecorationImage(
                                                                        // last visit code here
                                                                        image: NetworkImage(
                                                                            "${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                        fit: BoxFit
                                                                            .cover,
                                                                      ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              5),
                                                                      color: Colors
                                                                          .white,
                                                                    )
                                                                  : BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              5),
                                                                      color: Colors
                                                                          .black
                                                                          .withOpacity(
                                                                              0.7),
                                                                    ),
                                                          child: Padding(
                                                            padding:
                                                                EdgeInsets.all(
                                                              width * 0.0025,
                                                            ),
                                                            child: Column(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceAround,
                                                              children: [
                                                                Row(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceAround,
                                                                  children: [
                                                                    Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceAround,
                                                                      children: [
                                                                        // ---
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              2.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.12,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              color: Colors.transparent,
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),

                                                                        SizedBox(
                                                                            height:
                                                                                height * 0.1),

                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              2.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.12,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              color: Colors.transparent,
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceAround,
                                                                      children: [
                                                                        // ---

                                                                        // ...
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.10,
                                                                            height:
                                                                                width * 0.10,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              color: Colors.transparent,
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[2].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),

                                                                        SizedBox(
                                                                            height:
                                                                                height * 0.045),
                                                                        // ...
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.10,
                                                                            height:
                                                                                width * 0.10,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              color: Colors.transparent,
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[3].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),

                                                                        SizedBox(
                                                                            height:
                                                                                height * 0.045),

                                                                        // ...
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.10,
                                                                            height:
                                                                                width * 0.10,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              color: Colors.transparent,
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[4].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                    height: 12),
                                                                Center(
                                                                  child:
                                                                      Container(
                                                                    width:
                                                                        width *
                                                                            0.25,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              15),
                                                                      color: Color.fromARGB(
                                                                              255,
                                                                              80,
                                                                              133,
                                                                              123)
                                                                          .withOpacity(
                                                                              0.4),
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: const EdgeInsets
                                                                          .all(
                                                                          25.0),
                                                                      child:
                                                                          Text(
                                                                        string_logo !=
                                                                                ""
                                                                            ? string_logo.toString().toUpperCase()
                                                                            : "Photobooth Text",
                                                                        style:
                                                                            TextStyle(
                                                                          fontSize:
                                                                              35,
                                                                          color:
                                                                              Colors.white,
                                                                          fontWeight:
                                                                              FontWeight.w900,
                                                                        ),
                                                                        textAlign:
                                                                            TextAlign.center,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                    height:
                                                                        height *
                                                                            0.01),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    :

                                                    // ..................
                                                    // layout 4 main view
                                                    // ..................
                                                    choose_layout2 ==
                                                                "layout 4" &&
                                                            url_image_b2
                                                                .isNotEmpty
                                                        ? Container(
                                                            width: 600,
                                                            height: 900,
                                                            decoration:
                                                                choose_background !=
                                                                        ""
                                                                    ? BoxDecoration(
                                                                        image:
                                                                            DecorationImage(
                                                                          // last visit code here
                                                                          image:
                                                                              NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                          fit: BoxFit
                                                                              .cover,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .white,
                                                                      )
                                                                    : BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(5),
                                                                        color: Colors
                                                                            .black
                                                                            .withOpacity(0.7),
                                                                      ),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                width * 0.0025,
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                children: [
                                                                  // .................................
                                                                  // layout row drag target main view
                                                                  // .................................
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 0
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.0925,
                                                                            height:
                                                                                width * 0.0925,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ============
                                                                      // kolom card 1
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 2
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[2].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ============
                                                                      // kolom card 3
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[3].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 4
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[4].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ======================
                                                                      // kolom card 6 main view
                                                                      // ======================
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[5].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceEvenly,
                                                                    children: [
                                                                      // .............................
                                                                      // layout drag target main view
                                                                      // .............................

                                                                      // ============
                                                                      // kolom card 4
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[6].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // ======================
                                                                      // kolom card 6 main view
                                                                      // ======================
                                                                      Container(
                                                                        width: width *
                                                                            0.092,
                                                                        height: width *
                                                                            0.092,
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              5.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                width * 0.12,
                                                                            height:
                                                                                width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              image: DecorationImage(
                                                                                image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[7].toString()}"),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                  SizedBox(
                                                                      height:
                                                                          12),
                                                                  Center(
                                                                    child:
                                                                        Container(
                                                                      width: width *
                                                                          0.25,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(15),
                                                                        color: Color.fromARGB(
                                                                                255,
                                                                                80,
                                                                                133,
                                                                                123)
                                                                            .withOpacity(0.4),
                                                                      ),
                                                                      child:
                                                                          Padding(
                                                                        padding: const EdgeInsets
                                                                            .all(
                                                                            25.0),
                                                                        child:
                                                                            Text(
                                                                          string_logo != ""
                                                                              ? string_logo.toString().toUpperCase()
                                                                              : "Photobooth Text",
                                                                          style:
                                                                              TextStyle(
                                                                            fontSize:
                                                                                35,
                                                                            color:
                                                                                Colors.white,
                                                                            fontWeight:
                                                                                FontWeight.w900,
                                                                          ),
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                      height: height *
                                                                          0.01),
                                                                ],
                                                              ),
                                                            ),
                                                          )
                                                        :

                                                        // ..................
                                                        // layout 5 main view
                                                        // ..................
                                                        choose_layout2 ==
                                                                    "layout 5" &&
                                                                url_image_b2
                                                                    .isNotEmpty
                                                            ? Container(
                                                                width: 600,
                                                                height: 900,
                                                                decoration:
                                                                    choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.black.withOpacity(0.7),
                                                                          ),
                                                                child: Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceEvenly,
                                                                  children: [
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceEvenly,
                                                                      children: [
                                                                        // .................................
                                                                        // layout row drag target main view
                                                                        // .................................
                                                                        Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceEvenly,
                                                                          children: [
                                                                            // .............................
                                                                            // layout drag target main view
                                                                            // .............................

                                                                            // ============
                                                                            // dragtarget 1
                                                                            Container(
                                                                              width: width * 0.12,
                                                                              height: width * 0.12,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage(
                                                                                    "${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}",
                                                                                    scale: 1,
                                                                                  ),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),

                                                                            // ...
                                                                            SizedBox(height: height * 0.05),
                                                                            // ============
                                                                            // dragtarget 2
                                                                            Container(
                                                                              width: width * 0.12,
                                                                              height: width * 0.12,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}"

                                                                                      // "${Variables.ipv4_local}/storage/background/1720117923_bg1.jpg",
                                                                                      ),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),

                                                                            SizedBox(height: height * 0.1),
                                                                          ],
                                                                        ),

                                                                        // row 2
                                                                        Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceEvenly,
                                                                          children: [
                                                                            SizedBox(height: height * 0.1),
                                                                            // ...............................
                                                                            // layout drag target main view
                                                                            // .............................
                                                                            Container(
                                                                              width: width * 0.12,
                                                                              height: width * 0.12,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[2].toString()}"),
                                                                                  scale: 1,
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),

                                                                            SizedBox(height: height * 0.05),
                                                                            Container(
                                                                              width: width * 0.12,
                                                                              height: width * 0.12,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(12),
                                                                                color: Colors.transparent,
                                                                                image: DecorationImage(
                                                                                  image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[3].toString()}"),
                                                                                  fit: BoxFit.cover,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    SizedBox(
                                                                        height:
                                                                            12),
                                                                    Center(
                                                                      child:
                                                                          Container(
                                                                        width: width *
                                                                            0.25,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(15),
                                                                          color:
                                                                              Color.fromARGB(255, 80, 133, 123).withOpacity(0.4),
                                                                        ),
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              25.0),
                                                                          child:
                                                                              Text(
                                                                            string_logo != ""
                                                                                ? string_logo.toString().toUpperCase()
                                                                                : "Photobooth Text",
                                                                            style:
                                                                                TextStyle(
                                                                              fontSize: 35,
                                                                              color: Colors.white,
                                                                              fontWeight: FontWeight.w900,
                                                                            ),
                                                                            textAlign:
                                                                                TextAlign.center,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    SizedBox(
                                                                        height: height *
                                                                            0.01),
                                                                  ],
                                                                ),
                                                              )
                                                            : choose_layout2 ==
                                                                        "layout 6" &&
                                                                    url_image_b2
                                                                        .isNotEmpty
                                                                ? Container(
                                                                    width: 600,
                                                                    height: 900,
                                                                    decoration: choose_background !=
                                                                            ""
                                                                        ? BoxDecoration(
                                                                            image:
                                                                                DecorationImage(
                                                                              // last visit code here
                                                                              image: NetworkImage("${Variables.ipv4_local}/storage/background/${pilih_background2.toString()}"),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5),
                                                                            color:
                                                                                Colors.white,
                                                                          ),
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .all(
                                                                        width *
                                                                            0.0025,
                                                                      ),
                                                                      child:
                                                                          Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceEvenly,
                                                                        children: [
                                                                          Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.spaceEvenly,
                                                                            children: [
                                                                              // .................................
                                                                              // layout row drag target main view
                                                                              // .................................
                                                                              Column(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .............................
                                                                                  // layout drag target main view
                                                                                  // .............................

                                                                                  // ============
                                                                                  // kolom card 0
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[0].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  // ============
                                                                                  // kolom card 1
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[1].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[2].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),

                                                                              Column(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .............................
                                                                                  // layout drag target main view
                                                                                  // .............................

                                                                                  // ============
                                                                                  // kolom card 2
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[3].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  // ============
                                                                                  // kolom card 3
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[4].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[5].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),

                                                                              Column(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                                children: [
                                                                                  // .............................
                                                                                  // layout drag target main view
                                                                                  // .............................

                                                                                  // ============
                                                                                  // kolom card 4
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[6].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  // ======================
                                                                                  // kolom card 6 main view
                                                                                  // ======================
                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[7].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),

                                                                                  Container(
                                                                                    width: width * 0.07,
                                                                                    height: width * 0.07,
                                                                                    decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(5),
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    child: Padding(
                                                                                      padding: EdgeInsets.all(
                                                                                        width * 0.0001,
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: width * 0.07,
                                                                                        height: height * 0.07,
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(12),
                                                                                          image: DecorationImage(
                                                                                            image: NetworkImage("${Variables.ipv4_local}/storage/${url_image_b2[8].toString()}"),
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      // ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ],
                                                                          ),
                                                                          SizedBox(
                                                                              height: 12),
                                                                          Center(
                                                                            child:
                                                                                Container(
                                                                              width: width * 0.25,
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(15),
                                                                                color: Color.fromARGB(255, 80, 133, 123).withOpacity(0.4),
                                                                              ),
                                                                              child: Padding(
                                                                                padding: const EdgeInsets.all(25.0),
                                                                                child: Text(
                                                                                  string_logo != "" ? string_logo.toString().toUpperCase() : "Photobooth Text",
                                                                                  style: TextStyle(
                                                                                    fontSize: 35,
                                                                                    color: Colors.white,
                                                                                    fontWeight: FontWeight.w900,
                                                                                  ),
                                                                                  textAlign: TextAlign.center,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                              height: height * 0.01),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  )
                                                                : Container(),

                                        // SizedBox(
                                        //   height: height * 0.045,
                                        // ),
                                        // =======================
                                        // === end main layout ===
                                        // =======================
                                      ],
                          ),
                        ),
                      ),
                    ),
                  ),

                  // pilih layout / edit foto view
                  Container(
                    width: width * 0.25,
                    color: bg_warna_main != ""
                        ? HexColor(bg_warna_main)
                        : Colors.transparent,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                            top: width * 0.012,
                            bottom: width * 0.0,
                          ),
                          child: Text(
                            "Pilih Background",
                            style: TextStyle(
                              fontSize: width * 0.018,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),

                        // menu filter beauty
                        Padding(
                          padding: EdgeInsets.all(
                            width * 0.012,
                          ),
                          child: Container(
                            height: height * 0.55,
                            color: const Color.fromRGBO(0, 0, 0, 0),
                            child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: ScrollConfiguration(
                                behavior: ScrollConfiguration.of(context)
                                    .copyWith(scrollbars: false),
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.vertical,
                                  child: Wrap(
                                    alignment: WrapAlignment.start,
                                    verticalDirection: VerticalDirection.down,
                                    spacing: width * 0.017,
                                    runSpacing: width * 0.017,
                                    children: [
                                      for (var background in background)
                                        if (background["status"] == "aktif")
                                          InkWell(
                                            onTap: () {
                                              // ...
                                              setState(() {
                                                choose_background =
                                                    background["image"];
                                              });

                                              if (pilih_kanvas == "kanvas 1") {
                                                setState(() {
                                                  pilih_background1 =
                                                      background["image"];
                                                });
                                              } else {
                                                setState(() {
                                                  pilih_background2 =
                                                      background["image"];
                                                });
                                              }
                                            },
                                            child: Container(
                                              width: width * 0.085,
                                              height: height * 0.18,
                                              child: FadeInImage(
                                                width: width * 0.085,
                                                height: height * 0.18,
                                                image: NetworkImage(
                                                    "${Variables.ipv4_local}/storage/background/${background["image"].toString()}",
                                                    scale: 1),
                                                placeholder: AssetImage(
                                                    "assets/props/shapes/16_shapes_v1.png"),
                                                imageErrorBuilder: (context,
                                                    error, stackTrace) {
                                                  return Image.asset(
                                                      'assets/props/shapes/16_shapes_v1.png',
                                                      fit: BoxFit.cover);
                                                },
                                                fit: BoxFit.cover,
                                              ),
                                              // decoration: BoxDecoration(
                                              //   image: DecorationImage(
                                              //     image: NetworkImage(
                                              //       "${Variables.ipv4_local}/storage/background/${background["image"].toString()}",

                                              //       scale: 1,
                                              //     ),

                                              //     fit: BoxFit.cover,
                                              //   ),

                                              //   borderRadius:
                                              //       BorderRadius.circular(5),
                                              // ),
                                            ),
                                          ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),

                        // SizedBox(height: height * 0.08),

                        OutlinedButton(
                          style: TextButton.styleFrom(
                            textStyle: Theme.of(context).textTheme.labelLarge,
                            backgroundColor: Colors.black.withOpacity(0.7),
                          ),
                          onPressed: () {
                            // do onpressed...

                            // Navigator.push(
                            //   context,
                            //   PageTransition(
                            //       type: PageTransitionType.fade,
                            //       child: StickerWidget(
                            //         nama: nama,
                            //         title: title,
                            //         nama_filter: nama_filter,
                            //         choose_layout: choose_layout.toString(),
                            //         choose_layout2: title
                            //                     .toString()
                            //                     .contains("Collage B") ||
                            //                 title.toString().contains("Paket B")
                            //             ? choose_layout2.toString()
                            //             : null,

                            //         // drag item untuk card data collage dragItemB2, dragItemB1
                            //         drag_item: title
                            //                     .toString()
                            //                     .contains("Collage A") ||
                            //                 title.toString().contains("Paket A")
                            //             ? drag_item
                            //             : drag_item,
                            //         drag_item2: title
                            //                     .toString()
                            //                     .contains("Collage B") ||
                            //                 title.toString().contains("Paket B")
                            //             ? drag_item2
                            //             : null,
                            //         choose_background: choose_background,
                            //         backgrounds: backgrounds,

                            //         // pilih background
                            //         pilih_background1: pilih_background1,
                            //         pilih_background2: pilih_background2,
                            //       ),
                            //       inheritTheme: true,
                            //       ctx: context),
                            // );
                          },
                          child: Container(
                            // color: Colors.transparent,
                            width: width * 0.17,
                            // height: height * 0.012,
                            child: Padding(
                              padding: const EdgeInsets.only(
                                top: 8,
                                bottom: 8,
                              ),
                              child: Stack(
                                children: <Widget>[
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: FaIcon(
                                      FontAwesomeIcons.caretRight,
                                      color: Colors.white,
                                      size: width * 0.015,
                                    ),
                                  ),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "Selanjutnya".toUpperCase(),
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: width * 0.010,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ))
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: height * 0.047),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ... scroll customize
class NoThumbScrollBehavior extends ScrollBehavior {
  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.stylus,
        PointerDeviceKind.trackpad,
      };
}
