// ignore_for_file: unused_field

class Variables {
  // static const ipv4_server = "https://indophotobox.com/selfie"; // cpanel url
  static const ipv4_local = "http://127.0.0.1:8000"; // local url
  static const folder_img_path =
      "git/fs/fs-laravel/public/storage/uploads/images"; // local url
  static const folder_img_path_edit =
      "git/fs/fs-laravel/public/storage/uploads/images/edit"; // local url edit

  // colors wave
  static const _backgroundColor = "#43ff64d9";

  static const _colors1 = "#9EDEA0";
  static const _colors2 = "#97CE99";
}
